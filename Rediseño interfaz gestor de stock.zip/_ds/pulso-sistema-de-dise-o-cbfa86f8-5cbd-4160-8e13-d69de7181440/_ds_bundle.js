/* @ds-bundle: {"format":3,"namespace":"PulsoSistemaDeDiseO_cbfa86","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"StatusPill","sourcePath":"components/data-display/StatusPill.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"SegmentedTabs","sourcePath":"components/navigation/SegmentedTabs.jsx"},{"name":"DayPill","sourcePath":"components/scheduling/DayPill.jsx"},{"name":"TimeSlot","sourcePath":"components/scheduling/TimeSlot.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"115202090e1e","components/buttons/IconButton.jsx":"1f3bb02929d5","components/data-display/Avatar.jsx":"386774f1e08e","components/data-display/Badge.jsx":"1fca5ceb1c62","components/data-display/Card.jsx":"fbaf98cc2a8e","components/data-display/StatusPill.jsx":"09cb579086bd","components/forms/Checkbox.jsx":"8ad056cab701","components/forms/Input.jsx":"bcce185066bb","components/forms/Switch.jsx":"3567c1bb4798","components/navigation/SegmentedTabs.jsx":"90db13ee411f","components/scheduling/DayPill.jsx":"4f75a8fa415b","components/scheduling/TimeSlot.jsx":"ede27c2022df","ui_kits/clinica-admin/app.jsx":"65b9a8a77dd9","ui_kits/clinica-admin/data.jsx":"a00d0a237831","ui_kits/clinica-admin/login.jsx":"a8c94092f7a0","ui_kits/clinica-admin/shell.jsx":"9c7b960541bf","ui_kits/clinica-admin/views-operacion.jsx":"395606d1535b","ui_kits/clinica-admin/views-personas.jsx":"62ca69c40e74","ui_kits/clinica-medico/medico-data.jsx":"1e1a02515235","ui_kits/clinica-web/app.jsx":"704543970775","ui_kits/medico-web/medico-app.jsx":"d10ef830b8ea","ui_kits/medico-web/medico-views.jsx":"9da03362e1b3","ui_kits/paciente-movil/app.jsx":"cb216a4cbedf","ui_kits/paciente-web/paciente-app.jsx":"cc1e92a95a4f","ui_kits/paciente-web/paciente-views.jsx":"f4481c56cf71"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PulsoSistemaDeDiseO_cbfa86 = window.PulsoSistemaDeDiseO_cbfa86 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — acción principal de Pulso.
 * Mapea props a las clases del component layer (css/components.css).
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  block = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  disabled = false,
  className = '',
  ...rest
}) {
  const classes = ['pulso-btn', `pulso-btn--${variant}`, size !== 'md' ? `pulso-btn--${size}` : '', block ? 'pulso-btn--block' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: classes,
    disabled: disabled
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — acción compacta de solo icono (toolbars, headers, listas).
 * Recordá pasar aria-label para accesibilidad.
 */
function IconButton({
  icon,
  variant = 'plain',
  size = 'md',
  type = 'button',
  className = '',
  ...rest
}) {
  const classes = ['pulso-iconbtn', variant !== 'plain' ? `pulso-iconbtn--${variant}` : '', size === 'sm' ? 'pulso-iconbtn--sm' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: classes
  }, rest), icon);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Avatar — iniciales o imagen, circular (default) o cuadrado. */
function Avatar({
  name = '',
  src = null,
  size = 'md',
  square = false,
  className = '',
  ...rest
}) {
  const initials = name ? name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() : '';
  const classes = ['pulso-avatar', `pulso-avatar--${size}`, square ? 'pulso-avatar--square' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: classes
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Badge — etiqueta compacta para estados y categorías. */
function Badge({
  children,
  tone = 'neutral',
  icon = null,
  className = '',
  ...rest
}) {
  const classes = ['pulso-badge', `pulso-badge--${tone}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: classes
  }, rest), icon, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Card — contenedor base de Pulso (tarjetas de turno, paneles, listas). */
function Card({
  children,
  variant = 'raised',
  padded = false,
  interactive = false,
  className = '',
  ...rest
}) {
  const classes = ['pulso-card', variant === 'flat' ? 'pulso-card--flat' : '', variant === 'sunken' ? 'pulso-card--sunken' : '', padded ? 'pulso-card--pad' : '', interactive ? 'pulso-card--interactive' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/StatusPill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LABEL = {
  confirmed: 'Confirmado',
  pending: 'Pendiente',
  cancelled: 'Cancelado',
  attended: 'Atendido',
  available: 'Disponible'
};

/** StatusPill — punto de color + texto para el estado de un turno. */
function StatusPill({
  status = 'confirmed',
  children,
  className = '',
  ...rest
}) {
  const classes = ['pulso-status', `pulso-status--${status}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: classes
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "pulso-status__dot"
  }), children || LABEL[status]);
}
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Checkbox — casilla con label opcional. El check usa un icono de Lucide vía slot. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  checkIcon = null,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "pulso-check",
    "data-disabled": disabled || undefined
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "pulso-check__box"
  }, checkIcon), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — campo de texto de Pulso, con label/hint/error e icono opcional.
 */
function Input({
  label,
  hint,
  error,
  icon = null,
  id,
  className = '',
  ...rest
}) {
  const inputId = id || (label ? `f-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const inputEl = /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    className: ['pulso-input', error ? 'pulso-input--error' : '', className].filter(Boolean).join(' '),
    "aria-invalid": error ? 'true' : undefined
  }, rest));
  return /*#__PURE__*/React.createElement("div", {
    className: "pulso-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "pulso-field__label",
    htmlFor: inputId
  }, label), icon ? /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, icon), inputEl) : inputEl, error ? /*#__PURE__*/React.createElement("span", {
    className: "pulso-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "pulso-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Switch — interruptor on/off (recordatorios, disponibilidad, etc.). */
function Switch({
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "pulso-switch"
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__thumb"
  })));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SegmentedTabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SegmentedTabs — control segmentado para alternar vistas (Día/Semana, roles, etc.). */
function SegmentedTabs({
  items = [],
  value,
  onChange,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['pulso-seg', className].filter(Boolean).join(' '),
    role: "tablist"
  }, rest), items.map(it => {
    const v = typeof it === 'string' ? it : it.value;
    const label = typeof it === 'string' ? it : it.label;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      role: "tab",
      "aria-selected": value === v,
      className: "pulso-seg__item",
      onClick: () => onChange && onChange(v)
    }, label);
  }));
}
Object.assign(__ds_scope, { SegmentedTabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SegmentedTabs.jsx", error: String((e && e.message) || e) }); }

// components/scheduling/DayPill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** DayPill — día seleccionable (día de semana + número) para el selector de fecha. */
function DayPill({
  dow,
  day,
  selected = false,
  disabled = false,
  onSelect,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: ['pulso-day', className].filter(Boolean).join(' '),
    "aria-pressed": selected,
    disabled: disabled,
    onClick: onSelect
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "pulso-day__dow"
  }, dow), /*#__PURE__*/React.createElement("span", {
    className: "pulso-day__num"
  }, day));
}
Object.assign(__ds_scope, { DayPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/scheduling/DayPill.jsx", error: String((e && e.message) || e) }); }

// components/scheduling/TimeSlot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** TimeSlot — franja horaria seleccionable para reservar turnos. */
function TimeSlot({
  time,
  selected = false,
  disabled = false,
  filled = false,
  onSelect,
  className = '',
  ...rest
}) {
  const classes = ['pulso-slot', filled ? 'pulso-slot--filled' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: classes,
    "aria-pressed": selected,
    disabled: disabled,
    onClick: onSelect
  }, rest), time);
}
Object.assign(__ds_scope, { TimeSlot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/scheduling/TimeSlot.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-admin/app.jsx
try { (() => {
/* ============================================================
   Pulso · Panel admin — app (routing + estado)
   ============================================================ */
const {
  useState,
  useRef
} = React;
const META = {
  dashboard: ['Panel principal', 'Resumen del día'],
  turnos: ['Turnos', 'Supervisión de turnos'],
  horarios: ['Horarios', 'Agenda general de atención'],
  especialidades: ['Especialidades', 'Ramas médicas del hospital'],
  medicos: ['Médicos', 'Plantel de profesionales'],
  pacientes: ['Pacientes', 'Padrón de pacientes'],
  usuarios: ['Usuarios', 'Accesos al sistema'],
  pagos: ['Pagos', 'Aranceles y cobros'],
  suspensiones: ['Suspensiones', 'Control de inasistencias'],
  historiales: ['Historiales', 'Historias clínicas'],
  estadisticas: ['Estadísticas', 'Reportes del hospital']
};
const DASH_VARIANTS = [{
  id: 'resumen',
  label: 'Resumen'
}, {
  id: 'operativo',
  label: 'Operativo'
}, {
  id: 'analitico',
  label: 'Analítico'
}];
function AdminApp() {
  const [logged, setLogged] = useState(false);
  const [view, setView] = useState('dashboard');
  const [dashVar, setDashVar] = useState('resumen');
  const [toast, setToast] = useState('');
  const timer = useRef(null);
  const notify = msg => {
    setToast(msg);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(''), 2400);
  };
  const go = v => {
    setView(v);
    document.querySelector('.page')?.scrollTo?.(0, 0);
  };
  if (!logged) return /*#__PURE__*/React.createElement(Login, {
    onEnter: () => {
      setLogged(true);
      setView('dashboard');
    }
  });
  const [title, sub] = META[view] || ['', ''];
  const content = {
    dashboard: /*#__PURE__*/React.createElement(Dashboard, {
      variant: dashVar
    }),
    turnos: /*#__PURE__*/React.createElement(ViewTurnos, {
      notify: notify
    }),
    horarios: /*#__PURE__*/React.createElement(ViewHorarios, {
      notify: notify
    }),
    especialidades: /*#__PURE__*/React.createElement(ViewEspecialidades, {
      notify: notify
    }),
    medicos: /*#__PURE__*/React.createElement(ViewMedicos, {
      notify: notify
    }),
    pacientes: /*#__PURE__*/React.createElement(ViewPacientes, {
      notify: notify
    }),
    usuarios: /*#__PURE__*/React.createElement(ViewUsuarios, {
      notify: notify
    }),
    pagos: /*#__PURE__*/React.createElement(ViewPagos, {
      notify: notify
    }),
    suspensiones: /*#__PURE__*/React.createElement(ViewSuspensiones, {
      notify: notify
    }),
    historiales: /*#__PURE__*/React.createElement(ViewHistoriales, null),
    estadisticas: /*#__PURE__*/React.createElement(ViewEstadisticas, null)
  }[view];
  return /*#__PURE__*/React.createElement("div", {
    className: "adm"
  }, /*#__PURE__*/React.createElement(Sidebar, {
    view: view,
    go: go,
    onLogout: () => setLogged(false)
  }), /*#__PURE__*/React.createElement("div", {
    className: "main"
  }, /*#__PURE__*/React.createElement(Topbar, {
    title: title,
    sub: sub
  }, view === 'dashboard' && /*#__PURE__*/React.createElement("div", {
    className: "pulso-seg"
  }, DASH_VARIANTS.map(v => /*#__PURE__*/React.createElement("button", {
    key: v.id,
    className: "pulso-seg__item",
    "aria-selected": dashVar === v.id,
    onClick: () => setDashVar(v.id)
  }, v.label)))), content), /*#__PURE__*/React.createElement(Toast, {
    msg: toast
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(AdminApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-admin/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-admin/data.jsx
try { (() => {
/* ============================================================
   Pulso · Panel admin — datos de ejemplo (Hospital San Lucas)
   Expuestos en window.DATA para los demás scripts babel.
   ============================================================ */
const HOSPITAL = {
  nombre: 'Hospital San Lucas',
  red: 'Red de salud · Sede Centro'
};
const ESPECIALIDADES = [{
  id: 1,
  nombre: 'Cardiología',
  color: '#C0473B',
  icon: 'activity'
}, {
  id: 2,
  nombre: 'Clínica médica',
  color: '#1C5E44',
  icon: 'stethoscope'
}, {
  id: 3,
  nombre: 'Dermatología',
  color: '#C9852A',
  icon: 'scan-face'
}, {
  id: 4,
  nombre: 'Pediatría',
  color: '#2D6E9E',
  icon: 'baby'
}, {
  id: 5,
  nombre: 'Traumatología',
  color: '#6B4FA0',
  icon: 'bone'
}, {
  id: 6,
  nombre: 'Ginecología',
  color: '#B0427E',
  icon: 'venus'
}, {
  id: 7,
  nombre: 'Neurología',
  color: '#2FA86B',
  icon: 'brain'
}, {
  id: 8,
  nombre: 'Oftalmología',
  color: '#2A8F8F',
  icon: 'eye'
}];
const espById = id => ESPECIALIDADES.find(e => e.id === id);
const MEDICOS = [{
  id: 11,
  nombre: 'Lucía Romero',
  esp: 1,
  matricula: 'MP 12.834',
  dni: '28.114.502',
  email: 'l.romero@sanlucas.health',
  tel: '3624 41-2233'
}, {
  id: 12,
  nombre: 'Tomás Vidal',
  esp: 2,
  matricula: 'MP 14.207',
  dni: '30.551.118',
  email: 't.vidal@sanlucas.health',
  tel: '3624 47-8890'
}, {
  id: 13,
  nombre: 'Paula Sosa',
  esp: 3,
  matricula: 'MP 15.991',
  dni: '32.087.640',
  email: 'p.sosa@sanlucas.health',
  tel: '3624 15-7720'
}, {
  id: 14,
  nombre: 'Diego Ferreyra',
  esp: 4,
  matricula: 'MP 11.456',
  dni: '27.330.901',
  email: 'd.ferreyra@sanlucas.health',
  tel: '3624 42-0145'
}, {
  id: 15,
  nombre: 'Marina Quiroga',
  esp: 5,
  matricula: 'MP 16.778',
  dni: '33.642.215',
  email: 'm.quiroga@sanlucas.health',
  tel: '3624 46-3398'
}, {
  id: 16,
  nombre: 'Hernán Bianchi',
  esp: 7,
  matricula: 'MP 13.512',
  dni: '29.875.114',
  email: 'h.bianchi@sanlucas.health',
  tel: '3624 48-1167'
}, {
  id: 17,
  nombre: 'Carla Méndez',
  esp: 8,
  matricula: 'MP 17.209',
  dni: '34.118.776',
  email: 'c.mendez@sanlucas.health',
  tel: '3624 41-9054'
}];
const medById = id => MEDICOS.find(m => m.id === id);
const PACIENTES = [{
  id: 31,
  nombre: 'Ana Gil',
  dni: '40.118.223',
  email: 'ana.gil@correo.com',
  tel: '3624 15-2210',
  cobertura: 'OSDE',
  ausencias: 0,
  suspendido: false
}, {
  id: 32,
  nombre: 'Martín Acosta',
  dni: '38.902.551',
  email: 'm.acosta@correo.com',
  tel: '3624 15-8841',
  cobertura: 'Swiss Medical',
  ausencias: 1,
  suspendido: false
}, {
  id: 33,
  nombre: 'Jorge Ruiz',
  dni: '25.640.119',
  email: 'jruiz@correo.com',
  tel: '3624 15-3092',
  cobertura: 'Particular',
  ausencias: 0,
  suspendido: false
}, {
  id: 34,
  nombre: 'Elena Paz',
  dni: '41.557.882',
  email: 'elena.paz@correo.com',
  tel: '3624 15-7765',
  cobertura: 'OSDE',
  ausencias: 2,
  suspendido: false
}, {
  id: 35,
  nombre: 'Luis Mora',
  dni: '36.214.700',
  email: 'luis.mora@correo.com',
  tel: '3624 15-1138',
  cobertura: 'IOMA',
  ausencias: 3,
  suspendido: true,
  motivo: 'Tres inasistencias acumuladas sin aviso.'
}, {
  id: 36,
  nombre: 'Nora Díaz',
  dni: '39.880.412',
  email: 'nora.diaz@correo.com',
  tel: '3624 15-6620',
  cobertura: 'Swiss Medical',
  ausencias: 0,
  suspendido: false
}, {
  id: 37,
  nombre: 'Pedro Latorre',
  dni: '24.330.587',
  email: 'p.latorre@correo.com',
  tel: '3624 15-4471',
  cobertura: 'OSDE',
  ausencias: 3,
  suspendido: true,
  motivo: 'Suspensión preventiva por reiteradas ausencias.'
}, {
  id: 38,
  nombre: 'Mía Cruz',
  dni: '42.901.336',
  email: 'mia.cruz@correo.com',
  tel: '3624 15-9982',
  cobertura: 'IOMA',
  ausencias: 1,
  suspendido: false
}, {
  id: 39,
  nombre: 'Sara Vega',
  dni: '37.115.448',
  email: 'sara.vega@correo.com',
  tel: '3624 15-2055',
  cobertura: 'Particular',
  ausencias: 0,
  suspendido: false
}];
const pacById = id => PACIENTES.find(p => p.id === id);

// Usuarios del sistema (no médicos): admin, recepción, pacientes con login
const USUARIOS = [{
  id: 1,
  nombre: 'Sofía Maidana',
  email: 's.maidana@sanlucas.health',
  rol: 'ADMIN'
}, {
  id: 2,
  nombre: 'Raúl Benítez',
  email: 'r.benitez@sanlucas.health',
  rol: 'RECEPCIONISTA'
}, {
  id: 3,
  nombre: 'Valeria Ojeda',
  email: 'v.ojeda@sanlucas.health',
  rol: 'RECEPCIONISTA'
}, {
  id: 31,
  nombre: 'Ana Gil',
  email: 'ana.gil@correo.com',
  rol: 'PACIENTE'
}, {
  id: 32,
  nombre: 'Martín Acosta',
  email: 'm.acosta@correo.com',
  rol: 'PACIENTE'
}, {
  id: 34,
  nombre: 'Elena Paz',
  email: 'elena.paz@correo.com',
  rol: 'PACIENTE'
}];

// Turnos (estado: confirmed | pending | attended | cancelled | absent)
const TURNOS = [{
  id: 1042,
  fecha: '15 jun',
  hora: '08:00',
  esp: 1,
  med: 11,
  pac: 31,
  estado: 'attended'
}, {
  id: 1043,
  fecha: '15 jun',
  hora: '08:30',
  esp: 2,
  med: 12,
  pac: 32,
  estado: 'confirmed'
}, {
  id: 1044,
  fecha: '15 jun',
  hora: '09:00',
  esp: 3,
  med: 13,
  pac: 36,
  estado: 'confirmed'
}, {
  id: 1045,
  fecha: '15 jun',
  hora: '09:30',
  esp: 1,
  med: 11,
  pac: 33,
  estado: 'pending'
}, {
  id: 1046,
  fecha: '15 jun',
  hora: '10:00',
  esp: 4,
  med: 14,
  pac: 38,
  estado: 'confirmed'
}, {
  id: 1047,
  fecha: '15 jun',
  hora: '10:30',
  esp: 5,
  med: 15,
  pac: 34,
  estado: 'pending'
}, {
  id: 1048,
  fecha: '15 jun',
  hora: '11:00',
  esp: 7,
  med: 16,
  pac: 39,
  estado: 'confirmed'
}, {
  id: 1049,
  fecha: '15 jun',
  hora: '11:30',
  esp: 8,
  med: 17,
  pac: 35,
  estado: 'cancelled'
}, {
  id: 1050,
  fecha: '16 jun',
  hora: '08:30',
  esp: 2,
  med: 12,
  pac: 31,
  estado: 'confirmed'
}, {
  id: 1051,
  fecha: '16 jun',
  hora: '09:00',
  esp: 3,
  med: 13,
  pac: 33,
  estado: 'absent'
}, {
  id: 1052,
  fecha: '16 jun',
  hora: '10:00',
  esp: 1,
  med: 11,
  pac: 38,
  estado: 'confirmed'
}, {
  id: 1053,
  fecha: '16 jun',
  hora: '11:00',
  esp: 4,
  med: 14,
  pac: 36,
  estado: 'pending'
}];
const ESTADO_LABEL = {
  confirmed: 'Confirmado',
  pending: 'Pendiente',
  attended: 'Atendido',
  cancelled: 'Cancelado',
  absent: 'Ausente'
};
const ESTADO_KEYS = ['confirmed', 'pending', 'attended', 'cancelled', 'absent'];

// Agendas recurrentes por día de semana (0=Dom..6=Sáb)
const AGENDAS = [{
  id: 1,
  med: 11,
  esp: 1,
  dia: 1,
  ini: '08:00',
  fin: '12:00'
}, {
  id: 2,
  med: 12,
  esp: 2,
  dia: 1,
  ini: '09:00',
  fin: '13:00'
}, {
  id: 3,
  med: 13,
  esp: 3,
  dia: 2,
  ini: '08:00',
  fin: '11:00'
}, {
  id: 4,
  med: 14,
  esp: 4,
  dia: 2,
  ini: '14:00',
  fin: '18:00'
}, {
  id: 5,
  med: 15,
  esp: 5,
  dia: 3,
  ini: '08:00',
  fin: '12:00'
}, {
  id: 6,
  med: 16,
  esp: 7,
  dia: 4,
  ini: '10:00',
  fin: '14:00'
}, {
  id: 7,
  med: 11,
  esp: 1,
  dia: 4,
  ini: '08:00',
  fin: '11:00'
}, {
  id: 8,
  med: 17,
  esp: 8,
  dia: 5,
  ini: '09:00',
  fin: '13:00'
}, {
  id: 9,
  med: 12,
  esp: 2,
  dia: 5,
  ini: '14:00',
  fin: '17:00'
}];

// Historial médico de ejemplo (por paciente)
const HISTORIAL = {
  31: [{
    fecha: '15 jun 2026',
    titulo: 'Control cardiológico anual',
    med: 11,
    esp: 1,
    nota: 'Paciente estable. Presión 120/80. Se solicita ergometría de control para el próximo trimestre.'
  }, {
    fecha: '03 mar 2026',
    titulo: 'Consulta clínica',
    med: 12,
    esp: 2,
    nota: 'Cuadro gripal leve. Reposo 48 hs e hidratación. Sin signos de alarma.'
  }, {
    fecha: '12 nov 2025',
    titulo: 'Electrocardiograma',
    med: 11,
    esp: 1,
    nota: 'ECG dentro de parámetros normales. Ritmo sinusal.'
  }]
};

// Pagos (estado: paid | pending | refunded)
const PAGOS = [{
  id: 9001,
  turno: 1042,
  pac: 31,
  monto: 18500,
  metodo: 'Tarjeta',
  estado: 'paid',
  fecha: '15 jun'
}, {
  id: 9002,
  turno: 1043,
  pac: 32,
  monto: 0,
  metodo: 'Obra social',
  estado: 'pending',
  fecha: '15 jun'
}, {
  id: 9003,
  turno: 1044,
  pac: 36,
  monto: 22000,
  metodo: 'Efectivo',
  estado: 'paid',
  fecha: '15 jun'
}, {
  id: 9004,
  turno: 1045,
  pac: 33,
  monto: 18500,
  metodo: 'Tarjeta',
  estado: 'pending',
  fecha: '15 jun'
}, {
  id: 9005,
  turno: 1049,
  pac: 35,
  monto: 18500,
  metodo: 'Tarjeta',
  estado: 'refunded',
  fecha: '15 jun'
}, {
  id: 9006,
  turno: 1046,
  pac: 38,
  monto: 25000,
  metodo: 'Transferencia',
  estado: 'paid',
  fecha: '15 jun'
}];
const PAGO_LABEL = {
  paid: 'Pagado',
  pending: 'Pendiente',
  refunded: 'Reintegrado'
};

// Estadísticas: turnos por especialidad / estados / serie semanal
const STATS = {
  porEspecialidad: [{
    esp: 1,
    n: 128
  }, {
    esp: 2,
    n: 156
  }, {
    esp: 3,
    n: 92
  }, {
    esp: 4,
    n: 110
  }, {
    esp: 5,
    n: 74
  }, {
    esp: 7,
    n: 61
  }, {
    esp: 8,
    n: 48
  }],
  porEstado: [{
    k: 'attended',
    label: 'Atendidos',
    n: 512,
    color: 'var(--info)'
  }, {
    k: 'confirmed',
    label: 'Confirmados',
    n: 186,
    color: 'var(--success)'
  }, {
    k: 'cancelled',
    label: 'Cancelados',
    n: 73,
    color: 'var(--danger)'
  }, {
    k: 'absent',
    label: 'Ausentes',
    n: 41,
    color: 'var(--neutral-500)'
  }],
  semana: [{
    d: 'Lun',
    n: 38
  }, {
    d: 'Mar',
    n: 44
  }, {
    d: 'Mié',
    n: 41
  }, {
    d: 'Jue',
    n: 49
  }, {
    d: 'Vie',
    n: 52
  }, {
    d: 'Sáb',
    n: 21
  }]
};
const fmtMoneda = n => n === 0 ? '—' : '$' + n.toLocaleString('es-AR');
window.DATA = {
  HOSPITAL,
  ESPECIALIDADES,
  MEDICOS,
  PACIENTES,
  USUARIOS,
  TURNOS,
  AGENDAS,
  HISTORIAL,
  PAGOS,
  STATS,
  ESTADO_LABEL,
  ESTADO_KEYS,
  PAGO_LABEL,
  espById,
  medById,
  pacById,
  fmtMoneda
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-admin/data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-admin/login.jsx
try { (() => {
/* ============================================================
   Pulso · Panel admin — Login partido
   ============================================================ */
function Login({
  onEnter
}) {
  const D = window.DATA;
  return /*#__PURE__*/React.createElement("div", {
    className: "login"
  }, /*#__PURE__*/React.createElement("div", {
    className: "login__brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "login__brand-top"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark-light.svg",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "login__brand-name"
  }, "Pulso")), /*#__PURE__*/React.createElement("div", {
    className: "login__brand-mid"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "login__headline"
  }, "La gesti\xF3n de turnos, en calma."), /*#__PURE__*/React.createElement("p", {
    className: "login__sub"
  }, "Panel de administraci\xF3n de ", D.HOSPITAL.nombre, ". Turnos, agendas, profesionales y pacientes en un solo lugar."), /*#__PURE__*/React.createElement("div", {
    className: "login__chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-check",
    size: 15
  }), "Agenda unificada"), /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 15
  }), "Acceso por roles"), /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "activity",
    size: 15
  }), "Reportes en vivo"))), /*#__PURE__*/React.createElement("div", {
    className: "login__foot"
  }, "\xA9 2026 Pulso \xB7 ", D.HOSPITAL.red)), /*#__PURE__*/React.createElement("div", {
    className: "login__form"
  }, /*#__PURE__*/React.createElement("form", {
    className: "loginform",
    onSubmit: e => {
      e.preventDefault();
      onEnter();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "loginform__eyebrow"
  }, "Acceso al panel"), /*#__PURE__*/React.createElement("h1", {
    className: "loginform__title"
  }, "Inici\xE1 sesi\xF3n"), /*#__PURE__*/React.createElement("p", {
    className: "loginform__lead"
  }, "Ingres\xE1 con tu cuenta del hospital para administrar el sistema."), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Correo electr\xF3nico"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "mail",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "pulso-input",
    type: "email",
    defaultValue: "s.maidana@sanlucas.health",
    placeholder: "usuario@sanlucas.health"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Contrase\xF1a"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "pulso-input",
    type: "password",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    placeholder: "Ingres\xE1 tu contrase\xF1a"
  })), /*#__PURE__*/React.createElement("div", {
    className: "loginform__aux"
  }, /*#__PURE__*/React.createElement("span", {
    className: "loginlink"
  }, "\xBFOlvidaste tu contrase\xF1a?"))), /*#__PURE__*/React.createElement("div", {
    className: "loginform__cta"
  }, /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "pulso-btn pulso-btn--primary pulso-btn--lg pulso-btn--block"
  }, "Iniciar sesi\xF3n", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  }))), /*#__PURE__*/React.createElement("p", {
    className: "loginform__alt"
  }, "\xBFSos paciente? ", /*#__PURE__*/React.createElement("span", {
    className: "loginlink"
  }, "Cre\xE1 tu cuenta")))));
}
window.Login = Login;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-admin/login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-admin/shell.jsx
try { (() => {
/* ============================================================
   Pulso · Panel admin — shell (Icon, átomos, Sidebar, Topbar)
   ============================================================ */
const {
  useState,
  useRef,
  useLayoutEffect,
  useEffect
} = React;
const D = window.DATA;

/* ---------- Icono (Lucide) ---------- */
function Icon({
  name,
  size = 20,
  color,
  style
}) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.innerHTML = `<i data-lucide="${name}"></i>`;
    window.lucide && window.lucide.createIcons();
    const svg = el.querySelector('svg');
    if (svg) {
      svg.style.width = size + 'px';
      svg.style.height = size + 'px';
      svg.style.display = 'block';
      if (color) svg.style.color = color;
    }
  });
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      ...style
    }
  });
}

/* ---------- Átomos ---------- */
const initials = name => name.replace(/^(Dra?\.|Dr\.)\s*/, '').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
function Avatar({
  name,
  size = 38,
  tone,
  color
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "pulso-avatar",
    style: {
      width: size,
      height: size,
      fontSize: Math.round(size * 0.36),
      background: tone,
      color: color || (tone ? '#fff' : undefined)
    }
  }, initials(name));
}
function StatusPill({
  status
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: `pulso-status pulso-status--${status}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-status__dot"
  }), D.ESTADO_LABEL[status]);
}
function Badge({
  children,
  variant = 'neutral',
  icon
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: `pulso-badge pulso-badge--${variant}`
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 13
  }), children);
}
function RolBadge({
  rol
}) {
  const map = {
    ADMIN: 'primary',
    RECEPCIONISTA: 'info',
    PACIENTE: 'neutral',
    DOCTOR: 'success'
  };
  const label = {
    ADMIN: 'Admin',
    RECEPCIONISTA: 'Recepción',
    PACIENTE: 'Paciente',
    DOCTOR: 'Médico'
  };
  return /*#__PURE__*/React.createElement(Badge, {
    variant: map[rol]
  }, label[rol] || rol);
}

/* ---------- Sidebar ---------- */
const NAV = [{
  group: 'Principal',
  items: [{
    id: 'dashboard',
    label: 'Panel principal',
    icon: 'layout-dashboard'
  }]
}, {
  group: 'Operación',
  items: [{
    id: 'turnos',
    label: 'Turnos',
    icon: 'clipboard-list',
    count: () => D.TURNOS.length
  }, {
    id: 'horarios',
    label: 'Horarios',
    icon: 'calendar-days'
  }, {
    id: 'especialidades',
    label: 'Especialidades',
    icon: 'activity',
    count: () => D.ESPECIALIDADES.length
  }]
}, {
  group: 'Personas',
  items: [{
    id: 'medicos',
    label: 'Médicos',
    icon: 'stethoscope',
    count: () => D.MEDICOS.length
  }, {
    id: 'pacientes',
    label: 'Pacientes',
    icon: 'users-round',
    count: () => D.PACIENTES.length
  }, {
    id: 'usuarios',
    label: 'Usuarios',
    icon: 'shield-user'
  }]
}, {
  group: 'Administración',
  items: [{
    id: 'pagos',
    label: 'Pagos',
    icon: 'credit-card'
  }, {
    id: 'suspensiones',
    label: 'Suspensiones',
    icon: 'ban',
    count: () => D.PACIENTES.filter(p => p.suspendido).length
  }, {
    id: 'historiales',
    label: 'Historiales',
    icon: 'folder-open'
  }, {
    id: 'estadisticas',
    label: 'Estadísticas',
    icon: 'chart-column'
  }]
}];
function Sidebar({
  view,
  go,
  onLogout
}) {
  return /*#__PURE__*/React.createElement("aside", {
    className: "side"
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.svg",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "side__brandname"
  }, "Pulso")), /*#__PURE__*/React.createElement("div", {
    className: "side__ws",
    onClick: () => go('dashboard')
  }, /*#__PURE__*/React.createElement("span", {
    className: "side__ws-ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "hospital",
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__ws-name"
  }, D.HOSPITAL.nombre), /*#__PURE__*/React.createElement("div", {
    className: "side__ws-meta"
  }, "Panel de administraci\xF3n")), /*#__PURE__*/React.createElement(Icon, {
    name: "chevrons-up-down",
    size: 15,
    color: "var(--text-subtle)"
  })), /*#__PURE__*/React.createElement("nav", {
    className: "side__nav"
  }, NAV.map(sec => /*#__PURE__*/React.createElement("div", {
    key: sec.group
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__group"
  }, sec.group), sec.items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    className: 'navitem' + (view === it.id ? ' is-active' : ''),
    onClick: () => go(it.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 19
  }), /*#__PURE__*/React.createElement("span", null, it.label), it.count && /*#__PURE__*/React.createElement("span", {
    className: "navitem__count"
  }, it.count())))))), /*#__PURE__*/React.createElement("div", {
    className: "side__foot"
  }, /*#__PURE__*/React.createElement("button", {
    className: "navitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 19
  }), /*#__PURE__*/React.createElement("span", null, "Configuraci\xF3n")), /*#__PURE__*/React.createElement("div", {
    className: "side__user"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Sof\xEDa Maidana",
    size: 36,
    tone: "var(--primary)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__user-name"
  }, "Sof\xEDa Maidana"), /*#__PURE__*/React.createElement("div", {
    className: "side__user-role"
  }, "Administradora")), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--sm",
    title: "Cerrar sesi\xF3n",
    onClick: onLogout
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 17
  })))));
}

/* ---------- Topbar ---------- */
function Topbar({
  title,
  sub,
  children,
  noSearch
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "top"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "top__title"
  }, title), sub && /*#__PURE__*/React.createElement("p", {
    className: "top__sub"
  }, sub)), /*#__PURE__*/React.createElement("div", {
    className: "top__actions"
  }, !noSearch && /*#__PURE__*/React.createElement("div", {
    className: "searchbox"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 17
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Busc\xE1 paciente, m\xE9dico o turno\u2026"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--outline",
    title: "Notificaciones"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 18
  })), children));
}

/* ---------- Toast ---------- */
function Toast({
  msg
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'toast' + (msg ? ' is-on' : '')
  }, msg && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle-2",
    size: 18
  }), msg));
}

/* ---------- Panel (sección con tarjeta) ---------- */
function Panel({
  title,
  sub,
  actions,
  children,
  flush
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "panel"
  }, (title || actions) && /*#__PURE__*/React.createElement("div", {
    className: "panel__head"
  }, title && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "panel__title"
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    className: "panel__sub"
  }, sub)), actions && /*#__PURE__*/React.createElement("div", {
    className: "panel__actions"
  }, actions)), /*#__PURE__*/React.createElement("div", {
    className: 'panel__body' + (flush ? ' panel__body--flush' : '')
  }, children));
}
Object.assign(window, {
  Icon,
  Avatar,
  StatusPill,
  Badge,
  RolBadge,
  Sidebar,
  Topbar,
  Toast,
  Panel,
  initials
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-admin/shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-admin/views-operacion.jsx
try { (() => {
/* ============================================================
   Pulso · Panel admin — vistas: Especialidades, Horarios
   (calendario), Estadísticas, Historiales, Pagos, Suspensiones
   ============================================================ */
const {
  useState
} = React;
const Do = window.DATA;

/* ---------- Especialidades ---------- */
function ViewEspecialidades({
  notify
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Registrar especialidad",
    sub: "Defin\xED el nombre y un color de referencia"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 220
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Nombre de la rama m\xE9dica"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Ej: Endocrinolog\xEDa"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 120
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Color"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "color",
    defaultValue: "#1C5E44"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => notify('Especialidad registrada')
  }, "Guardar"))), /*#__PURE__*/React.createElement(Panel, {
    title: "Especialidades activas",
    sub: `${Do.ESPECIALIDADES.length} ramas médicas`,
    flush: true
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Especialidad"), /*#__PURE__*/React.createElement("th", null, "Color"), /*#__PURE__*/React.createElement("th", null, "Profesionales"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Gesti\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, Do.ESPECIALIDADES.map(e => {
    const n = Do.MEDICOS.filter(m => m.esp === e.id).length;
    return /*#__PURE__*/React.createElement("tr", {
      key: e.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "cellflex"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espcard__ic",
      style: {
        background: e.color,
        width: 32,
        height: 32
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: e.icon,
      size: 17
    })), /*#__PURE__*/React.createElement("span", {
      className: "tbl__name"
    }, e.nombre))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "cellflex"
    }, /*#__PURE__*/React.createElement("span", {
      className: "colorchip",
      style: {
        background: e.color
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "tbl__muted",
      style: {
        fontFamily: 'var(--font-num)'
      }
    }, e.color))), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, n, " ", n === 1 ? 'profesional' : 'profesionales'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn rowbtn--danger",
      onClick: () => notify('Especialidad eliminada: ' + e.nombre)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "trash-2",
      size: 14
    }), "Eliminar"))));
  })))));
}

/* ---------- Horarios (calendario mensual) ---------- */
const DOW = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
function ViewHorarios({
  notify
}) {
  const year = 2026,
    month = 5; // junio
  const firstDow = new Date(year, month, 1).getDay(); // 0=Dom
  const offset = firstDow === 0 ? 6 : firstDow - 1; // semana empieza Lun
  const days = new Date(year, month + 1, 0).getDate();
  const today = 15;
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push(/*#__PURE__*/React.createElement("div", {
    key: 'e' + i,
    className: "cal__cell cal__cell--muted"
  }));
  for (let d = 1; d <= days; d++) {
    const wd = new Date(year, month, d).getDay();
    const evs = Do.AGENDAS.filter(a => a.dia === wd);
    cells.push(/*#__PURE__*/React.createElement("div", {
      className: "cal__cell",
      key: d
    }, /*#__PURE__*/React.createElement("span", {
      className: 'cal__num' + (d === today ? ' cal__num--today' : '')
    }, d), evs.map(a => {
      const e = Do.espById(a.esp),
        m = Do.medById(a.med);
      return /*#__PURE__*/React.createElement("div", {
        className: "cal__ev",
        key: a.id,
        style: {
          background: e.color + '1f',
          borderLeftColor: e.color,
          color: 'var(--text-body)'
        },
        onClick: () => notify(`${e.nombre} · Dr. ${m.nombre} · ${a.ini}–${a.fin}`)
      }, a.ini, " ", m.nombre.split(' ')[0]);
    })));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Cargar bloque de atenci\xF3n recurrente",
    sub: "Se repite cada semana en el d\xEDa elegido"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 170
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Especialidad"), /*#__PURE__*/React.createElement("select", {
    className: "fld"
  }, /*#__PURE__*/React.createElement("option", null, "Seleccion\xE1\u2026"), Do.ESPECIALIDADES.map(e => /*#__PURE__*/React.createElement("option", {
    key: e.id
  }, e.nombre)))), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 170
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Profesional"), /*#__PURE__*/React.createElement("select", {
    className: "fld"
  }, /*#__PURE__*/React.createElement("option", null, "Seleccion\xE1\u2026"), Do.MEDICOS.map(m => /*#__PURE__*/React.createElement("option", {
    key: m.id
  }, "Dr. ", m.nombre)))), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "D\xEDa"), /*#__PURE__*/React.createElement("select", {
    className: "fld"
  }, /*#__PURE__*/React.createElement("option", null, "Lunes"), /*#__PURE__*/React.createElement("option", null, "Martes"), /*#__PURE__*/React.createElement("option", null, "Mi\xE9rcoles"), /*#__PURE__*/React.createElement("option", null, "Jueves"), /*#__PURE__*/React.createElement("option", null, "Viernes"), /*#__PURE__*/React.createElement("option", null, "S\xE1bado"))), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 120
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Hora inicio"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "time",
    defaultValue: "08:00"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 120
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Hora fin"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "time",
    defaultValue: "12:00"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => notify('Bloque de atención guardado')
  }, "Guardar"))), /*#__PURE__*/React.createElement("div", {
    className: "cal",
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal__bar"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--outline pulso-iconbtn--sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "cal__month"
  }, "Junio 2026"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--outline pulso-iconbtn--sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, Do.ESPECIALIDADES.slice(0, 5).map(e => /*#__PURE__*/React.createElement("span", {
    key: e.id,
    className: "espchip",
    style: {
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "espdot",
    style: {
      background: e.color
    }
  }), e.nombre)))), /*#__PURE__*/React.createElement("div", {
    className: "cal__head"
  }, DOW.map(d => /*#__PURE__*/React.createElement("div", {
    key: d,
    className: "cal__dow"
  }, d))), /*#__PURE__*/React.createElement("div", {
    className: "cal__grid"
  }, cells)));
}

/* ---------- Estadísticas ---------- */
function ViewEstadisticas() {
  const espRows = Do.STATS.porEspecialidad.map(r => ({
    label: Do.espById(r.esp).nombre,
    n: r.n,
    color: Do.espById(r.esp).color,
    dot: Do.espById(r.esp).color
  }));
  const total = Do.STATS.porEstado.reduce((s, r) => s + r.n, 0);
  const atendidos = Do.STATS.porEstado.find(r => r.k === 'attended').n;
  const cancelados = Do.STATS.porEstado.find(r => r.k === 'cancelled').n;
  const kpis = [{
    v: total,
    k: 'Turnos del período',
    icon: 'calendar-days',
    tone: 'ic-primary'
  }, {
    v: atendidos,
    k: 'Atendidos',
    icon: 'circle-check-big',
    tone: 'ic-info'
  }, {
    v: Math.round(atendidos / total * 100) + '%',
    k: 'Tasa de asistencia',
    icon: 'percent',
    tone: 'ic-accent'
  }, {
    v: cancelados,
    k: 'Cancelaciones',
    icon: 'circle-x',
    tone: 'ic-danger'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Per\xEDodo de an\xE1lisis",
    sub: "Eleg\xED el rango a reportar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 180
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Desde"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "date",
    defaultValue: "2026-06-01"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 180
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Hasta"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "date",
    defaultValue: "2026-06-30"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chart-column",
    size: 16
  }), "Ver estad\xEDsticas"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary"
  }, "Ver todo"))), /*#__PURE__*/React.createElement("div", {
    className: "kpis",
    style: {
      marginTop: 20
    }
  }, kpis.map(it => /*#__PURE__*/React.createElement("div", {
    className: "kpi",
    key: it.k
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'kpi__ic ' + it.tone
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "kpi__v"
  }, it.v), /*#__PURE__*/React.createElement("div", {
    className: "kpi__k"
  }, it.k)))), /*#__PURE__*/React.createElement("div", {
    className: "cols cols--2-1"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Turnos por especialidad",
    sub: "Junio 2026"
  }, /*#__PURE__*/React.createElement(BarList, {
    rows: espRows
  })), /*#__PURE__*/React.createElement(Panel, {
    title: "Resultado de turnos"
  }, /*#__PURE__*/React.createElement(StackedBar, {
    rows: Do.STATS.porEstado
  }))), /*#__PURE__*/React.createElement(Panel, {
    title: "Turnos por d\xEDa",
    sub: "Distribuci\xF3n semanal"
  }, /*#__PURE__*/React.createElement(BarList, {
    rows: Do.STATS.semana.map(s => ({
      label: s.d,
      n: s.n
    }))
  })));
}

/* ---------- Historiales ---------- */
function ViewHistoriales() {
  const [pacId, setPacId] = useState(31);
  const items = Do.HISTORIAL[pacId];
  const pac = Do.pacById(pacId);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Historiales m\xE9dicos",
    sub: "Consult\xE1 la evoluci\xF3n cl\xEDnica de un paciente"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 240
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Paciente"), /*#__PURE__*/React.createElement("select", {
    className: "fld",
    value: pacId,
    onChange: e => setPacId(Number(e.target.value))
  }, Do.PACIENTES.map(p => /*#__PURE__*/React.createElement("option", {
    key: p.id,
    value: p.id
  }, p.nombre, " \u2014 ", p.dni)))), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16
  }), "Ver historial"))), items ? /*#__PURE__*/React.createElement(Panel, {
    title: "Historia cl\xEDnica",
    sub: `${pac.nombre} · ${pac.cobertura} · DNI ${pac.dni}`,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "printer",
      size: 14
    }), "Imprimir")
  }, /*#__PURE__*/React.createElement("div", {
    className: "tl"
  }, items.map((h, i) => {
    const m = Do.medById(h.med),
      e = Do.espById(h.esp);
    return /*#__PURE__*/React.createElement("div", {
      className: "tl__item",
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      className: "tl__dot",
      style: {
        background: e.color
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "tl__date"
    }, h.fecha), /*#__PURE__*/React.createElement("div", {
      className: "tl__card"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tl__title"
    }, h.titulo), /*#__PURE__*/React.createElement("div", {
      className: "tl__meta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espchip",
      style: {
        fontSize: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "espdot",
      style: {
        background: e.color
      }
    }), e.nombre), " \xB7 Dr. ", m.nombre), /*#__PURE__*/React.createElement("div", {
      className: "tl__note"
    }, h.nota)));
  }))) : /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "empty__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "folder-open",
    size: 30
  })), /*#__PURE__*/React.createElement("div", {
    className: "empty__t"
  }, "Sin registros"), /*#__PURE__*/React.createElement("p", {
    className: "empty__p"
  }, pac.nombre, " todav\xEDa no tiene consultas cargadas en su historia cl\xEDnica."))));
}

/* ---------- Pagos ---------- */
function ViewPagos({
  notify
}) {
  const recaudado = Do.PAGOS.filter(p => p.estado === 'paid').reduce((s, p) => s + p.monto, 0);
  const pendiente = Do.PAGOS.filter(p => p.estado === 'pending').reduce((s, p) => s + p.monto, 0);
  const variant = {
    paid: 'success',
    pending: 'warning',
    refunded: 'neutral'
  };
  const pagoIc = {
    paid: 'circle-check',
    pending: 'clock',
    refunded: 'rotate-ccw'
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpis kpis--3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "kpi__ic ic-primary"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "wallet",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "kpi__v"
  }, Do.fmtMoneda(recaudado)), /*#__PURE__*/React.createElement("div", {
    className: "kpi__k"
  }, "Recaudado hoy")), /*#__PURE__*/React.createElement("div", {
    className: "kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "kpi__ic ic-warning"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "clock",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "kpi__v"
  }, Do.fmtMoneda(pendiente)), /*#__PURE__*/React.createElement("div", {
    className: "kpi__k"
  }, "Pendiente de cobro")), /*#__PURE__*/React.createElement("div", {
    className: "kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "kpi__ic ic-info"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "receipt",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "kpi__v"
  }, Do.PAGOS.length), /*#__PURE__*/React.createElement("div", {
    className: "kpi__k"
  }, "Movimientos"))), /*#__PURE__*/React.createElement(Panel, {
    title: "Gesti\xF3n de pagos",
    sub: "Aranceles de consultas del d\xEDa",
    flush: true,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 14
    }), "Exportar")
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Comprobante"), /*#__PURE__*/React.createElement("th", null, "Turno"), /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "M\xE9todo"), /*#__PURE__*/React.createElement("th", null, "Monto"), /*#__PURE__*/React.createElement("th", null, "Estado"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acci\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, Do.PAGOS.map(p => {
    const pac = Do.pacById(p.pac);
    return /*#__PURE__*/React.createElement("tr", {
      key: p.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "tbl__id"
    }, "#", p.id)), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, "T-", String(p.turno).padStart(4, '0')), /*#__PURE__*/React.createElement("td", {
      className: "tbl__name"
    }, pac.nombre), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, p.metodo), /*#__PURE__*/React.createElement("td", {
      style: {
        fontFamily: 'var(--font-num)',
        fontWeight: 700,
        color: 'var(--text-strong)'
      }
    }, Do.fmtMoneda(p.monto)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
      variant: variant[p.estado],
      icon: pagoIc[p.estado]
    }, Do.PAGO_LABEL[p.estado])), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => notify('Comprobante #' + p.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "eye",
      size: 14
    }), "Ver"))));
  })))));
}

/* ---------- Suspensiones ---------- */
function ViewSuspensiones({
  notify
}) {
  const suspendidos = Do.PACIENTES.filter(p => p.suspendido);
  const enRiesgo = Do.PACIENTES.filter(p => !p.suspendido && p.ausencias >= 2);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "banner banner--warn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "banner__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "triangle-alert",
    size: 20
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "banner__t"
  }, "Pol\xEDtica de inasistencias"), /*#__PURE__*/React.createElement("div", {
    className: "banner__p"
  }, "El sistema suspende autom\xE1ticamente a los pacientes al acumular 3 inasistencias sin aviso. La reactivaci\xF3n es manual y queda registrada."))), /*#__PURE__*/React.createElement(Panel, {
    title: "Pacientes suspendidos",
    sub: `${suspendidos.length} cuentas restringidas`,
    flush: true
  }, suspendidos.length ? /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "DNI"), /*#__PURE__*/React.createElement("th", null, "Ausencias"), /*#__PURE__*/React.createElement("th", null, "Motivo"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acci\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, suspendidos.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p.id
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "cellflex"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.nombre,
    size: 36,
    tone: "var(--danger)"
  }), /*#__PURE__*/React.createElement("span", {
    className: "tbl__name"
  }, p.nombre))), /*#__PURE__*/React.createElement("td", {
    className: "tbl__muted"
  }, p.dni), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-num)',
      fontWeight: 700,
      color: 'var(--danger)'
    }
  }, p.ausencias), /*#__PURE__*/React.createElement("span", {
    className: "tbl__muted"
  }, " / 3")), /*#__PURE__*/React.createElement("td", {
    className: "tbl__muted",
    style: {
      maxWidth: 320
    }
  }, p.motivo), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "tbl__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "rowbtn rowbtn--ok",
    onClick: () => notify(p.nombre + ' reactivado')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-check",
    size: 14
  }), "Reactivar"))))))) : /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "empty__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 30
  })), /*#__PURE__*/React.createElement("div", {
    className: "empty__t"
  }, "Sin suspensiones"))), /*#__PURE__*/React.createElement(Panel, {
    title: "En riesgo de suspensi\xF3n",
    sub: "Pacientes con 2 inasistencias",
    flush: true
  }, enRiesgo.length ? /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "DNI"), /*#__PURE__*/React.createElement("th", null, "Ausencias"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acci\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, enRiesgo.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p.id
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "cellflex"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.nombre,
    size: 36,
    tone: "var(--warning)"
  }), /*#__PURE__*/React.createElement("span", {
    className: "tbl__name"
  }, p.nombre))), /*#__PURE__*/React.createElement("td", {
    className: "tbl__muted"
  }, p.dni), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-num)',
      fontWeight: 700,
      color: 'var(--warning-ink)'
    }
  }, p.ausencias), /*#__PURE__*/React.createElement("span", {
    className: "tbl__muted"
  }, " / 3")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "tbl__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "rowbtn",
    onClick: () => notify('Aviso enviado a ' + p.nombre)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "mail",
    size: 14
  }), "Enviar aviso"))))))) : /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "empty__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-check",
    size: 30
  })), /*#__PURE__*/React.createElement("div", {
    className: "empty__t"
  }, "Nadie en riesgo"))));
}
Object.assign(window, {
  ViewEspecialidades,
  ViewHorarios,
  ViewEstadisticas,
  ViewHistoriales,
  ViewPagos,
  ViewSuspensiones
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-admin/views-operacion.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-admin/views-personas.jsx
try { (() => {
/* ============================================================
   Pulso · Panel admin — vistas: Dashboard (3 variantes),
   Turnos, Médicos, Pacientes, Usuarios + helpers de gráfico
   ============================================================ */
const {
  useState
} = React;
const Dd = window.DATA;
const HOY = '15 jun';

/* ---------- helpers de gráfico (reutilizados en Estadísticas) ---------- */
function BarList({
  rows
}) {
  const max = Math.max(...rows.map(r => r.n));
  return /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "bar",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "bar__label"
  }, r.dot && /*#__PURE__*/React.createElement("span", {
    className: "espdot",
    style: {
      background: r.dot,
      width: 10,
      height: 10
    }
  }), r.label), /*#__PURE__*/React.createElement("span", {
    className: "bar__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "bar__fill",
    style: {
      width: r.n / max * 100 + '%',
      background: r.color || 'var(--primary)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "bar__val"
  }, r.n))));
}
function StackedBar({
  rows
}) {
  const total = rows.reduce((s, r) => s + r.n, 0);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: 16,
      borderRadius: 999,
      overflow: 'hidden',
      marginBottom: 18
    }
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: r.n / total * 100 + '%',
      background: r.color
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "legend"
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "legend__row",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "legend__dot",
    style: {
      background: r.color
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "legend__k"
  }, r.label), /*#__PURE__*/React.createElement("span", {
    className: "legend__v"
  }, r.n, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-subtle)',
      fontWeight: 600
    }
  }, "\xB7 ", Math.round(r.n / total * 100), "%"))))));
}

/* ---------- piezas del dashboard ---------- */
function KpiRow() {
  const hoy = Dd.TURNOS.filter(t => t.fecha === HOY);
  const cuenta = k => hoy.filter(t => t.estado === k).length;
  const items = [{
    v: hoy.length,
    k: 'Turnos hoy',
    icon: 'calendar-days',
    tone: 'ic-primary',
    delta: '+12%',
    dir: 'up'
  }, {
    v: cuenta('confirmed'),
    k: 'Confirmados',
    icon: 'circle-check-big',
    tone: 'ic-info',
    delta: '+3',
    dir: 'up'
  }, {
    v: cuenta('pending'),
    k: 'Pendientes',
    icon: 'circle-dashed',
    tone: 'ic-warning',
    delta: '2 por revisar',
    dir: 'flat'
  }, {
    v: cuenta('cancelled') + cuenta('absent'),
    k: 'Cancelados / ausentes',
    icon: 'circle-x',
    tone: 'ic-danger',
    delta: '−1',
    dir: 'down'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "kpis"
  }, items.map(it => /*#__PURE__*/React.createElement("div", {
    className: "kpi",
    key: it.k
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'kpi__ic ' + it.tone
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    className: 'kpi__delta kpi__delta--' + it.dir
  }, it.dir !== 'flat' && /*#__PURE__*/React.createElement(Icon, {
    name: it.dir === 'up' ? 'trending-up' : 'trending-down',
    size: 14
  }), it.delta)), /*#__PURE__*/React.createElement("div", {
    className: "kpi__v"
  }, it.v), /*#__PURE__*/React.createElement("div", {
    className: "kpi__k"
  }, it.k))));
}
function ProximosTurnos({
  limit = 6
}) {
  const hoy = Dd.TURNOS.filter(t => t.fecha === HOY).slice(0, limit);
  return /*#__PURE__*/React.createElement("div", {
    className: "mini"
  }, hoy.map(t => {
    const med = Dd.medById(t.med),
      esp = Dd.espById(t.esp),
      pac = Dd.pacById(t.pac);
    return /*#__PURE__*/React.createElement("div", {
      className: "mini__row",
      key: t.id
    }, /*#__PURE__*/React.createElement("span", {
      className: "mini__time"
    }, t.hora), /*#__PURE__*/React.createElement(Avatar, {
      name: pac.nombre,
      size: 36
    }), /*#__PURE__*/React.createElement("div", {
      className: "mini__main"
    }, /*#__PURE__*/React.createElement("div", {
      className: "mini__who"
    }, pac.nombre), /*#__PURE__*/React.createElement("div", {
      className: "mini__sub"
    }, esp.nombre, " \xB7 Dr. ", med.nombre.split(' ')[1] || med.nombre)), /*#__PURE__*/React.createElement(StatusPill, {
      status: t.estado
    }));
  }));
}
function EspecialidadesActivas() {
  return /*#__PURE__*/React.createElement("div", {
    className: "espgrid"
  }, Dd.ESPECIALIDADES.map(e => {
    const n = Dd.MEDICOS.filter(m => m.esp === e.id).length;
    return /*#__PURE__*/React.createElement("div", {
      className: "espcard",
      key: e.id
    }, /*#__PURE__*/React.createElement("span", {
      className: "espcard__ic",
      style: {
        background: e.color
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: e.icon,
      size: 18
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "espcard__name"
    }, e.nombre), /*#__PURE__*/React.createElement("div", {
      className: "espcard__meta"
    }, n, " ", n === 1 ? 'profesional' : 'profesionales')));
  }));
}
function Dashboard({
  variant
}) {
  const espRows = Dd.STATS.porEspecialidad.map(r => ({
    label: Dd.espById(r.esp).nombre,
    n: r.n,
    color: Dd.espById(r.esp).color,
    dot: Dd.espById(r.esp).color
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page__intro"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, HOY, " \xB7 Lunes"), /*#__PURE__*/React.createElement("div", {
    className: "page__hello"
  }, "Buenas tardes, Sof\xEDa"), /*#__PURE__*/React.createElement("div", {
    className: "page__date"
  }, "Esto es lo que pasa hoy en ", Dd.HOSPITAL.nombre, ".")), /*#__PURE__*/React.createElement(KpiRow, null), variant === 'resumen' && /*#__PURE__*/React.createElement("div", {
    className: "cols cols--2-1"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Pr\xF3ximos turnos de hoy",
    sub: "Agenda general \xB7 todas las especialidades",
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 14
    }), "Ver agenda")
  }, /*#__PURE__*/React.createElement(ProximosTurnos, null)), /*#__PURE__*/React.createElement(Panel, {
    title: "Especialidades activas"
  }, /*#__PURE__*/React.createElement(EspecialidadesActivas, null))), variant === 'operativo' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Panel, {
    title: "Turnos de hoy",
    sub: `${Dd.TURNOS.filter(t => t.fecha === HOY).length} turnos programados`,
    flush: true,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 14
    }), "Nuevo turno")
  }, /*#__PURE__*/React.createElement(TurnosTabla, {
    soloHoy: true
  })), /*#__PURE__*/React.createElement("div", {
    className: "cols cols--1-1",
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Carga por especialidad",
    sub: "Turnos del mes"
  }, /*#__PURE__*/React.createElement(BarList, {
    rows: espRows
  })), /*#__PURE__*/React.createElement(Panel, {
    title: "Resultado de turnos",
    sub: "Acumulado del mes"
  }, /*#__PURE__*/React.createElement(StackedBar, {
    rows: Dd.STATS.porEstado
  })))), variant === 'analitico' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "cols cols--2-1"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Turnos por especialidad",
    sub: "Mes en curso"
  }, /*#__PURE__*/React.createElement(BarList, {
    rows: espRows
  })), /*#__PURE__*/React.createElement(Panel, {
    title: "Resultado de turnos"
  }, /*#__PURE__*/React.createElement(StackedBar, {
    rows: Dd.STATS.porEstado
  }))), /*#__PURE__*/React.createElement(Panel, {
    title: "Turnos por d\xEDa",
    sub: "\xDAltima semana",
    actions: /*#__PURE__*/React.createElement(Badge, {
      variant: "success",
      icon: "trending-up"
    }, "+8% vs. semana previa")
  }, /*#__PURE__*/React.createElement(BarList, {
    rows: Dd.STATS.semana.map(s => ({
      label: s.d,
      n: s.n
    }))
  }))));
}

/* ---------- Turnos ---------- */
function TurnosTabla({
  soloHoy,
  notify
}) {
  const rows = soloHoy ? Dd.TURNOS.filter(t => t.fecha === HOY) : Dd.TURNOS;
  return /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "C\xF3digo"), /*#__PURE__*/React.createElement("th", null, "Fecha \xB7 hora"), /*#__PURE__*/React.createElement("th", null, "Especialidad"), /*#__PURE__*/React.createElement("th", null, "Profesional"), /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "Estado"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acci\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, rows.map(t => {
    const med = Dd.medById(t.med),
      esp = Dd.espById(t.esp),
      pac = Dd.pacById(t.pac);
    return /*#__PURE__*/React.createElement("tr", {
      key: t.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "tbl__id"
    }, "T-", String(t.id).padStart(4, '0'))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "tbl__name",
      style: {
        fontWeight: 600
      }
    }, t.fecha), " ", /*#__PURE__*/React.createElement("span", {
      className: "tbl__muted"
    }, "\xB7 ", t.hora, " hs")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "espchip"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espdot",
      style: {
        background: esp.color
      }
    }), esp.nombre)), /*#__PURE__*/React.createElement("td", null, "Dr. ", med.nombre), /*#__PURE__*/React.createElement("td", {
      className: "tbl__name"
    }, pac.nombre), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(StatusPill, {
      status: t.estado
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => notify && notify('Detalle del turno T-' + t.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "eye",
      size: 14
    }), "Ver"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn rowbtn--danger",
      onClick: () => notify && notify('Turno T-' + t.id + ' cancelado')
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "x",
      size: 14
    }), "Cancelar"))));
  })));
}
function ViewTurnos({
  notify
}) {
  const [estado, setEstado] = useState('');
  const [esp, setEsp] = useState('');
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Supervisar turnos",
    sub: "Todos los turnos del sistema",
    flush: true,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "pulso-btn pulso-btn--primary pulso-btn--sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 16
    }), "Nuevo turno")
  }, /*#__PURE__*/React.createElement("div", {
    className: "filters"
  }, /*#__PURE__*/React.createElement("select", {
    className: "fld",
    style: {
      width: 215
    },
    value: esp,
    onChange: e => setEsp(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Todas las especialidades"), Dd.ESPECIALIDADES.map(e => /*#__PURE__*/React.createElement("option", {
    key: e.id,
    value: e.id
  }, e.nombre))), /*#__PURE__*/React.createElement("select", {
    className: "fld",
    style: {
      width: 170
    },
    value: estado,
    onChange: e => setEstado(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Todos los estados"), Dd.ESTADO_KEYS.map(k => /*#__PURE__*/React.createElement("option", {
    key: k,
    value: k
  }, Dd.ESTADO_LABEL[k]))), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "date",
    style: {
      width: 170
    },
    defaultValue: "2026-06-15"
  }), /*#__PURE__*/React.createElement("div", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement("button", {
    className: "rowbtn"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "download",
    size: 14
  }), "Exportar")), /*#__PURE__*/React.createElement(FiltradoTurnos, {
    estado: estado,
    esp: esp,
    notify: notify
  })));
}
function FiltradoTurnos({
  estado,
  esp,
  notify
}) {
  let rows = Dd.TURNOS;
  if (estado) rows = rows.filter(t => t.estado === estado);
  if (esp) rows = rows.filter(t => t.esp === Number(esp));
  if (!rows.length) return /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "empty__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-search",
    size: 30
  })), /*#__PURE__*/React.createElement("div", {
    className: "empty__t"
  }, "Sin turnos"), /*#__PURE__*/React.createElement("p", {
    className: "empty__p"
  }, "No hay turnos que coincidan con los filtros seleccionados."));
  return /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "C\xF3digo"), /*#__PURE__*/React.createElement("th", null, "Fecha \xB7 hora"), /*#__PURE__*/React.createElement("th", null, "Especialidad"), /*#__PURE__*/React.createElement("th", null, "Profesional"), /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "Estado"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acci\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, rows.map(t => {
    const med = Dd.medById(t.med),
      e = Dd.espById(t.esp),
      pac = Dd.pacById(t.pac);
    return /*#__PURE__*/React.createElement("tr", {
      key: t.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "tbl__id"
    }, "T-", String(t.id).padStart(4, '0'))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600,
        color: 'var(--text-strong)'
      }
    }, t.fecha), " ", /*#__PURE__*/React.createElement("span", {
      className: "tbl__muted"
    }, "\xB7 ", t.hora, " hs")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "espchip"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espdot",
      style: {
        background: e.color
      }
    }), e.nombre)), /*#__PURE__*/React.createElement("td", null, "Dr. ", med.nombre), /*#__PURE__*/React.createElement("td", {
      className: "tbl__name"
    }, pac.nombre), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(StatusPill, {
      status: t.estado
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => notify('Detalle del turno T-' + t.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "eye",
      size: 14
    }), "Ver"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn rowbtn--danger",
      onClick: () => notify('Turno T-' + t.id + ' cancelado')
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "x",
      size: 14
    }), "Cancelar"))));
  })));
}

/* ---------- Médicos ---------- */
function ViewMedicos({
  notify
}) {
  const [open, setOpen] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, open && /*#__PURE__*/React.createElement(FormMedico, {
    onClose: () => setOpen(false),
    notify: notify
  }), /*#__PURE__*/React.createElement(Panel, {
    title: "Gesti\xF3n de m\xE9dicos",
    sub: `${Dd.MEDICOS.length} profesionales activos`,
    flush: true,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "pulso-btn pulso-btn--primary pulso-btn--sm",
      onClick: () => setOpen(o => !o)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: open ? 'x' : 'plus',
      size: 16
    }), open ? 'Cerrar' : 'Agregar médico')
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Profesional"), /*#__PURE__*/React.createElement("th", null, "Especialidad"), /*#__PURE__*/React.createElement("th", null, "Matr\xEDcula"), /*#__PURE__*/React.createElement("th", null, "DNI"), /*#__PURE__*/React.createElement("th", null, "Contacto"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acciones"))), /*#__PURE__*/React.createElement("tbody", null, Dd.MEDICOS.map(m => {
    const e = Dd.espById(m.esp);
    return /*#__PURE__*/React.createElement("tr", {
      key: m.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "cellflex"
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: m.nombre,
      size: 38,
      tone: e.color
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__name"
    }, "Dr. ", m.nombre), /*#__PURE__*/React.createElement("div", {
      className: "tbl__muted",
      style: {
        fontSize: 12.5
      }
    }, m.email)))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "espchip"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espdot",
      style: {
        background: e.color
      }
    }), e.nombre)), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, m.matricula), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, m.dni), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, m.tel), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => setOpen(true)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "pencil",
      size: 14
    }), "Editar"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn rowbtn--danger",
      onClick: () => notify('Médico eliminado: Dr. ' + m.nombre)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "trash-2",
      size: 14
    }), "Eliminar"))));
  })))));
}
function FormMedico({
  onClose,
  notify
}) {
  return /*#__PURE__*/React.createElement(Panel, {
    title: "Agregar nuevo m\xE9dico",
    sub: "Se crear\xE1 una cuenta de acceso para el profesional"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Nombre"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Ej: Juan"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Apellido"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Ej: P\xE9rez"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1.4,
      minWidth: 200
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Correo de acceso"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "doctor@sanlucas.health"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 130
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "DNI"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "30.123.456"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 130
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Matr\xEDcula"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "MP 12.345"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 170
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Especialidad"), /*#__PURE__*/React.createElement("select", {
    className: "fld"
  }, /*#__PURE__*/React.createElement("option", null, "Seleccion\xE1\u2026"), Dd.ESPECIALIDADES.map(e => /*#__PURE__*/React.createElement("option", {
    key: e.id
  }, e.nombre)))), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 140
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Contrase\xF1a inicial"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "password",
    placeholder: "M\xEDnimo 4 caracteres"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => {
      notify('Médico agregado correctamente');
      onClose();
    }
  }, "Guardar"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary",
    onClick: onClose
  }, "Cancelar")));
}

/* ---------- Pacientes ---------- */
function ViewPacientes({
  notify
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Gesti\xF3n de pacientes",
    sub: `${Dd.PACIENTES.length} pacientes registrados`,
    flush: true,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 14
    }), "Exportar")
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "DNI"), /*#__PURE__*/React.createElement("th", null, "Cobertura"), /*#__PURE__*/React.createElement("th", null, "Ausencias"), /*#__PURE__*/React.createElement("th", null, "Estado"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acciones"))), /*#__PURE__*/React.createElement("tbody", null, Dd.PACIENTES.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p.id,
    style: p.suspendido ? {
      background: 'color-mix(in srgb, var(--danger-soft) 45%, transparent)'
    } : null
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "cellflex"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.nombre,
    size: 38
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "tbl__name"
  }, p.nombre), /*#__PURE__*/React.createElement("div", {
    className: "tbl__muted",
    style: {
      fontSize: 12.5
    }
  }, p.email)))), /*#__PURE__*/React.createElement("td", {
    className: "tbl__muted"
  }, p.dni), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
    variant: "neutral",
    icon: "shield"
  }, p.cobertura)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-num)',
      fontWeight: 700,
      color: p.ausencias >= 3 ? 'var(--danger)' : p.ausencias >= 2 ? 'var(--warning-ink)' : 'var(--text-muted)'
    }
  }, p.ausencias), /*#__PURE__*/React.createElement("span", {
    className: "tbl__muted"
  }, " / 3")), /*#__PURE__*/React.createElement("td", null, p.suspendido ? /*#__PURE__*/React.createElement(Badge, {
    variant: "danger",
    icon: "ban"
  }, "Suspendido") : /*#__PURE__*/React.createElement(Badge, {
    variant: "success",
    icon: "circle-check"
  }, "Activo")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "tbl__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "rowbtn",
    onClick: () => notify('Agendar turno para ' + p.nombre)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-plus",
    size: 14
  }), "Agendar"), p.suspendido ? /*#__PURE__*/React.createElement("button", {
    className: "rowbtn rowbtn--ok",
    onClick: () => notify(p.nombre + ' reactivado')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-check",
    size: 14
  }), "Reactivar") : /*#__PURE__*/React.createElement("button", {
    className: "rowbtn rowbtn--warn",
    onClick: () => notify(p.nombre + ' suspendido')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ban",
    size: 14
  }), "Suspender")))))))));
}

/* ---------- Usuarios ---------- */
function ViewUsuarios({
  notify
}) {
  const [open, setOpen] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, open && /*#__PURE__*/React.createElement(Panel, {
    title: "Agregar usuario",
    sub: "Cuentas de administraci\xF3n, recepci\xF3n o pacientes"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Nombre"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Ej: Juan"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Apellido"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Ej: P\xE9rez"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1.4,
      minWidth: 200
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Correo electr\xF3nico"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "usuario@sanlucas.health"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Rol"), /*#__PURE__*/React.createElement("select", {
    className: "fld"
  }, /*#__PURE__*/React.createElement("option", null, "Administrador"), /*#__PURE__*/React.createElement("option", null, "Recepcionista"), /*#__PURE__*/React.createElement("option", null, "Paciente"))), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      flex: 1,
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Contrase\xF1a"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "password",
    placeholder: "M\xEDnimo 4 caracteres"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => {
      notify('Usuario creado');
      setOpen(false);
    }
  }, "Guardar"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary",
    onClick: () => setOpen(false)
  }, "Cancelar"))), /*#__PURE__*/React.createElement(Panel, {
    title: "Usuarios del sistema",
    sub: "Accesos de administraci\xF3n, recepci\xF3n y pacientes",
    flush: true,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "pulso-btn pulso-btn--primary pulso-btn--sm",
      onClick: () => setOpen(o => !o)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: open ? 'x' : 'plus',
      size: 16
    }), open ? 'Cerrar' : 'Agregar usuario')
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Usuario"), /*#__PURE__*/React.createElement("th", null, "Correo"), /*#__PURE__*/React.createElement("th", null, "Rol"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acciones"))), /*#__PURE__*/React.createElement("tbody", null, Dd.USUARIOS.map(u => /*#__PURE__*/React.createElement("tr", {
    key: u.id
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "cellflex"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: u.nombre,
    size: 36,
    tone: u.rol === 'ADMIN' ? 'var(--primary)' : undefined
  }), /*#__PURE__*/React.createElement("span", {
    className: "tbl__name"
  }, u.nombre))), /*#__PURE__*/React.createElement("td", {
    className: "tbl__muted"
  }, u.email), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(RolBadge, {
    rol: u.rol
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "tbl__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "rowbtn",
    onClick: () => setOpen(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "pencil",
    size: 14
  }), "Editar"), /*#__PURE__*/React.createElement("button", {
    className: "rowbtn rowbtn--danger",
    onClick: () => notify('Usuario eliminado: ' + u.nombre)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trash-2",
    size: 14
  }), "Eliminar")))))))));
}
Object.assign(window, {
  Dashboard,
  ViewTurnos,
  ViewMedicos,
  ViewPacientes,
  ViewUsuarios,
  BarList,
  StackedBar,
  TurnosTabla
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-admin/views-personas.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-medico/medico-data.jsx
try { (() => {
/* ============================================================
   Pulso · Panel médico — datos del día (Dra. Lucía Romero)
   Reutiliza window.DATA (del kit admin) y agrega window.MEDDATA.
   ============================================================ */
const ME = {
  id: 11,
  nombre: 'Lucía Romero',
  esp: 'Cardiología',
  cons: 'Consultorio 4',
  matricula: 'MP 12.834',
  color: '#C0473B'
};

// Agenda de hoy (estado: attended | pending | confirmed | available | cancelled | absent)
const AGENDA_HOY = [{
  id: 'a1',
  hora: '08:00',
  pac: 'Ana Gil',
  edad: 58,
  cobertura: 'OSDE',
  motivo: 'Control anual',
  estado: 'attended'
}, {
  id: 'a2',
  hora: '08:30',
  pac: 'Roberto Sosa',
  edad: 64,
  cobertura: 'Swiss Medical',
  motivo: 'Control post-internación',
  estado: 'attended'
}, {
  id: 'a3',
  hora: '09:00',
  pac: 'Jorge Ruiz',
  edad: 47,
  cobertura: 'Particular',
  motivo: 'Electrocardiograma',
  estado: 'pending'
}, {
  id: 'a4',
  hora: '09:30',
  pac: 'Elena Paz',
  edad: 39,
  cobertura: 'OSDE',
  motivo: 'Palpitaciones',
  estado: 'confirmed'
}, {
  id: 'a5',
  hora: '10:00',
  pac: 'Hugo Maza',
  edad: 71,
  cobertura: 'IOMA',
  motivo: 'Control de marcapasos',
  estado: 'confirmed'
}, {
  id: 'a6',
  hora: '10:30',
  pac: null,
  edad: null,
  cobertura: null,
  motivo: 'Espacio libre',
  estado: 'available'
}, {
  id: 'a7',
  hora: '11:00',
  pac: 'Mía Cruz',
  edad: 33,
  cobertura: 'IOMA',
  motivo: 'Primera consulta',
  estado: 'confirmed'
}, {
  id: 'a8',
  hora: '11:30',
  pac: 'Pedro Latorre',
  edad: 55,
  cobertura: 'OSDE',
  motivo: 'Hipertensión',
  estado: 'confirmed'
}];

// Disponibilidad semanal del profesional
const HORARIOS = [{
  dia: 'Lunes',
  activo: true,
  ini: '08:00',
  fin: '12:00'
}, {
  dia: 'Martes',
  activo: true,
  ini: '14:00',
  fin: '18:00'
}, {
  dia: 'Miércoles',
  activo: true,
  ini: '08:00',
  fin: '12:00'
}, {
  dia: 'Jueves',
  activo: false,
  ini: '08:00',
  fin: '12:00'
}, {
  dia: 'Viernes',
  activo: true,
  ini: '08:00',
  fin: '11:00'
}, {
  dia: 'Sábado',
  activo: false,
  ini: '09:00',
  fin: '13:00'
}];

// Antecedentes del paciente activo (para la pantalla de Atención)
const HIST_PREVIO = {
  'Jorge Ruiz': [{
    fecha: '12 mar 2026',
    titulo: 'Consulta cardiológica',
    nota: 'Soplo sistólico leve. Se solicita ecocardiograma. PA 140/90.'
  }, {
    fecha: '04 nov 2025',
    titulo: 'Electrocardiograma',
    nota: 'Ritmo sinusal. Sin alteraciones agudas.'
  }]
};
window.MEDDATA = {
  ME,
  AGENDA_HOY,
  HORARIOS,
  HIST_PREVIO
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-medico/medico-data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clinica-web/app.jsx
try { (() => {
const {
  useState,
  useRef,
  useLayoutEffect
} = React;

/* ---------- Icono (Lucide) ---------- */
function Icon({
  name,
  size = 20,
  color,
  style
}) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const el = ref.current;
    el.innerHTML = `<i data-lucide="${name}"></i>`;
    window.lucide && window.lucide.createIcons();
    const svg = el.querySelector('svg');
    if (svg) {
      svg.style.width = size + 'px';
      svg.style.height = size + 'px';
      if (color) svg.style.color = color;
    }
  });
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      ...style
    }
  });
}

/* ---------- Datos ---------- */
const PROFS = [{
  id: 'romero',
  name: 'Dra. Lucía Romero',
  esp: 'Cardiología',
  cons: 'Cons. 4'
}, {
  id: 'vidal',
  name: 'Dr. Tomás Vidal',
  esp: 'Clínica médica',
  cons: 'Cons. 7'
}, {
  id: 'sosa',
  name: 'Dra. Paula Sosa',
  esp: 'Dermatología',
  cons: 'Cons. 12'
}];
const SLOTS = ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30'];
const ESTADO_LABEL = {
  confirmed: 'Confirmado',
  pending: 'Pendiente',
  attended: 'Atendido',
  cancelled: 'Cancelado'
};

// turnos por profesional: { start (índice de slot), span, patient, motivo, status, obra }
const TURNOS = {
  romero: [{
    id: 'r1',
    start: 0,
    span: 2,
    patient: 'Ana Gil',
    motivo: 'Control anual',
    status: 'attended',
    obra: 'OSDE'
  }, {
    id: 'r2',
    start: 3,
    span: 2,
    patient: 'Martín Acosta',
    motivo: 'Primera consulta',
    status: 'confirmed',
    obra: 'Swiss Medical'
  }, {
    id: 'r3',
    start: 6,
    span: 2,
    patient: 'Jorge Ruiz',
    motivo: 'Electrocardiograma',
    status: 'pending',
    obra: 'Particular'
  }, {
    id: 'r4',
    start: 10,
    span: 2,
    patient: 'Elena Paz',
    motivo: 'Control',
    status: 'confirmed',
    obra: 'OSDE'
  }],
  vidal: [{
    id: 'v1',
    start: 1,
    span: 2,
    patient: 'Sara Paz',
    motivo: 'Certificado',
    status: 'attended',
    obra: 'IOMA'
  }, {
    id: 'v2',
    start: 4,
    span: 2,
    patient: 'Luis Mora',
    motivo: 'Consulta general',
    status: 'confirmed',
    obra: 'OSDE'
  }, {
    id: 'v3',
    start: 8,
    span: 2,
    patient: 'Eva Sol',
    motivo: 'Control',
    status: 'confirmed',
    obra: 'Particular'
  }],
  sosa: [{
    id: 's1',
    start: 2,
    span: 2,
    patient: 'Nora Díaz',
    motivo: 'Lesión cutánea',
    status: 'confirmed',
    obra: 'Swiss Medical'
  }, {
    id: 's2',
    start: 5,
    span: 2,
    patient: 'Pedro Lat',
    motivo: 'Control de lunares',
    status: 'cancelled',
    obra: 'OSDE'
  }, {
    id: 's3',
    start: 9,
    span: 2,
    patient: 'Mía Cruz',
    motivo: 'Consulta',
    status: 'pending',
    obra: 'IOMA'
  }]
};
const MOTIVOS_CANCEL = ['El paciente no puede asistir', 'El profesional no está disponible', 'Superposición de turnos', 'Licencia médica', 'Otro motivo'];

/* ---------- Átomos ---------- */
const Avatar = ({
  name,
  size = 38,
  tone
}) => {
  const ini = name.replace(/^(Dra?\.|Dr\.)\s*/, '').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", {
    className: "pulso-avatar",
    style: {
      width: size,
      height: size,
      fontSize: size * 0.36,
      background: tone,
      color: tone ? '#fff' : undefined
    }
  }, ini);
};
const StatusPill = ({
  status
}) => /*#__PURE__*/React.createElement("span", {
  className: `pulso-status pulso-status--${status}`
}, /*#__PURE__*/React.createElement("span", {
  className: "pulso-status__dot"
}), ESTADO_LABEL[status]);

/* ---------- Sidebar ---------- */
function Sidebar() {
  const nav = [{
    icon: 'calendar-days',
    label: 'Agenda',
    active: true
  }, {
    icon: 'clipboard-list',
    label: 'Turnos'
  }, {
    icon: 'users-round',
    label: 'Pacientes'
  }, {
    icon: 'stethoscope',
    label: 'Profesionales'
  }, {
    icon: 'chart-no-axes-column',
    label: 'Reportes'
  }];
  return /*#__PURE__*/React.createElement("aside", {
    className: "sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sidebar__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.svg",
    width: "32",
    height: "32",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", null, "Pulso")), /*#__PURE__*/React.createElement("nav", {
    className: "sidebar__nav"
  }, nav.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.label,
    className: 'navitem' + (n.active ? ' is-active' : '')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n.icon,
    size: 20
  }), /*#__PURE__*/React.createElement("span", null, n.label)))), /*#__PURE__*/React.createElement("div", {
    className: "sidebar__foot"
  }, /*#__PURE__*/React.createElement("a", {
    className: "navitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 20
  }), /*#__PURE__*/React.createElement("span", null, "Configuraci\xF3n")), /*#__PURE__*/React.createElement("div", {
    className: "sidebar__user"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Carla M\xE9ndez",
    size: 36,
    tone: "var(--primary)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "sidebar__user-name"
  }, "Carla M\xE9ndez"), /*#__PURE__*/React.createElement("div", {
    className: "sidebar__user-role"
  }, "Recepci\xF3n")), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--text-subtle)"
  }))));
}

/* ---------- Topbar ---------- */
function Topbar({
  role,
  setRole,
  vista,
  setVista
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "topbar"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "topbar__title"
  }, "Agenda"), /*#__PURE__*/React.createElement("p", {
    className: "topbar__sub"
  }, "Martes 10 de junio, 2026")), /*#__PURE__*/React.createElement("div", {
    className: "topbar__center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "datenav"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 18
  })), /*#__PURE__*/React.createElement("button", {
    className: "datenav__today"
  }, "Hoy"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pulso-seg"
  }, ['Día', 'Semana', 'Mes'].map(v => /*#__PURE__*/React.createElement("button", {
    key: v,
    className: "pulso-seg__item",
    "aria-selected": vista === v,
    onClick: () => setVista(v)
  }, v)))), /*#__PURE__*/React.createElement("div", {
    className: "topbar__right"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rolepick"
  }, ['Recepción', 'Médico'].map(r => /*#__PURE__*/React.createElement("button", {
    key: r,
    className: 'rolepick__btn' + (role === r ? ' is-on' : ''),
    onClick: () => setRole(r)
  }, r))), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--outline"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 18
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 18
  }), "Nuevo turno")));
}

/* ---------- Tira de métricas ---------- */
function Stats() {
  const data = [{
    k: 'Turnos hoy',
    v: 10,
    icon: 'calendar-days',
    tone: 'var(--text-strong)'
  }, {
    k: 'Confirmados',
    v: 5,
    icon: 'circle-check',
    tone: 'var(--success)'
  }, {
    k: 'Pendientes',
    v: 2,
    icon: 'circle-dashed',
    tone: 'var(--warning)'
  }, {
    k: 'Cancelados',
    v: 1,
    icon: 'circle-x',
    tone: 'var(--danger)'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "stats"
  }, data.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.k,
    className: "stat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat__ic",
    style: {
      color: d.tone
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: d.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "stat__v"
  }, d.v), /*#__PURE__*/React.createElement("div", {
    className: "stat__k"
  }, d.k)))));
}

/* ---------- Panel de detalle ---------- */
function DetailPanel({
  turn,
  onClose,
  onCancel
}) {
  const [mode, setMode] = useState('view'); // view | cancel | done
  const [motivo, setMotivo] = useState(MOTIVOS_CANCEL[0]);
  React.useEffect(() => {
    setMode('view');
  }, [turn && turn.id]);
  if (!turn) return null;
  return /*#__PURE__*/React.createElement("aside", {
    className: "detail"
  }, /*#__PURE__*/React.createElement("div", {
    className: "detail__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail__eyebrow"
  }, "Detalle del turno"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--sm",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "detail__patient"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: turn.patient,
    size: 52,
    tone: "var(--primary)"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "detail__name"
  }, turn.patient), /*#__PURE__*/React.createElement(StatusPill, {
    status: mode === 'done' ? 'cancelled' : turn.status
  }))), /*#__PURE__*/React.createElement("div", {
    className: "detail__rows"
  }, /*#__PURE__*/React.createElement("div", {
    className: "drow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "drow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "stethoscope",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "drow__k"
  }, "Profesional"), /*#__PURE__*/React.createElement("div", {
    className: "drow__v"
  }, turn.prof.name))), /*#__PURE__*/React.createElement("div", {
    className: "drow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "drow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "drow__k"
  }, "Fecha y hora"), /*#__PURE__*/React.createElement("div", {
    className: "drow__v"
  }, "Mar 10 jun \xB7 ", SLOTS[turn.start], " hs"))), /*#__PURE__*/React.createElement("div", {
    className: "drow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "drow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "clipboard-list",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "drow__k"
  }, "Motivo"), /*#__PURE__*/React.createElement("div", {
    className: "drow__v"
  }, turn.motivo))), /*#__PURE__*/React.createElement("div", {
    className: "drow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "drow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "drow__k"
  }, "Cobertura"), /*#__PURE__*/React.createElement("div", {
    className: "drow__v"
  }, turn.obra)))), mode === 'view' && turn.status !== 'cancelled' && /*#__PURE__*/React.createElement("div", {
    className: "detail__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary pulso-btn--block"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 18
  }), "Marcar como atendido"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary pulso-btn--block"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-clock",
    size: 18
  }), "Reprogramar"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--ghost pulso-btn--block",
    style: {
      color: 'var(--danger)'
    },
    onClick: () => setMode('cancel')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 18
  }), "Cancelar turno")), mode === 'view' && turn.status === 'cancelled' && /*#__PURE__*/React.createElement("div", {
    className: "detail__cancelled"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-x",
    size: 18
  }), "Este turno fue cancelado."), mode === 'cancel' && /*#__PURE__*/React.createElement("div", {
    className: "cancelbox"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cancelbox__title"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "triangle-alert",
    size: 18,
    color: "var(--danger)"
  }), "Cancelar turno"), /*#__PURE__*/React.createElement("p", {
    className: "cancelbox__text"
  }, "Se notificar\xE1 al paciente por correo. Indic\xE1 el motivo de la cancelaci\xF3n:"), /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Motivo"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-input",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: motivo,
    onChange: e => setMotivo(e.target.value),
    className: "cancelbox__select"
  }, MOTIVOS_CANCEL.map(m => /*#__PURE__*/React.createElement("option", {
    key: m
  }, m)))), /*#__PURE__*/React.createElement("div", {
    className: "cancelbox__btns"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary",
    style: {
      flex: 1
    },
    onClick: () => setMode('view')
  }, "Volver"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--danger",
    style: {
      flex: 1
    },
    onClick: () => {
      setMode('done');
      onCancel(turn);
    }
  }, "Confirmar cancelaci\xF3n"))), mode === 'done' && /*#__PURE__*/React.createElement("div", {
    className: "detail__done"
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail__done-ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 22,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("div", {
    className: "detail__done-t"
  }, "Turno cancelado"), /*#__PURE__*/React.createElement("p", null, "Se le envi\xF3 un aviso al paciente con el motivo."), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary pulso-btn--block",
    onClick: onClose
  }, "Cerrar")));
}

/* ---------- App ---------- */
function ClinicaApp() {
  const [role, setRole] = useState('Recepción');
  const [vista, setVista] = useState('Día');
  const [selected, setSelected] = useState(null);
  const [cancelledIds, setCancelledIds] = useState([]);

  // aplica cancelaciones al dataset en memoria
  const decorate = t => cancelledIds.includes(t.id) ? {
    ...t,
    status: 'cancelled'
  } : t;
  return /*#__PURE__*/React.createElement("div", {
    className: "app"
  }, /*#__PURE__*/React.createElement(Sidebar, null), /*#__PURE__*/React.createElement("div", {
    className: "main"
  }, /*#__PURE__*/React.createElement(Topbar, {
    role: role,
    setRole: setRole,
    vista: vista,
    setVista: setVista
  }), /*#__PURE__*/React.createElement("div", {
    className: "content"
  }, /*#__PURE__*/React.createElement("div", {
    className: "content__scroll"
  }, /*#__PURE__*/React.createElement(Stats, null), /*#__PURE__*/React.createElement(AgendaWrapped, {
    role: role,
    selected: selected,
    onSelect: t => setSelected(decorate(t)),
    cancelledIds: cancelledIds
  })), selected && /*#__PURE__*/React.createElement(DetailPanel, {
    turn: selected,
    onClose: () => setSelected(null),
    onCancel: t => setCancelledIds(ids => [...ids, t.id])
  }))));
}

// envuelve Agenda para aplicar cancelaciones a los bloques
function AgendaWrapped({
  role,
  selected,
  onSelect,
  cancelledIds
}) {
  const cols = role === 'Médico' ? PROFS.slice(0, 1) : PROFS;
  return /*#__PURE__*/React.createElement("div", {
    className: "agenda",
    style: {
      gridTemplateColumns: `64px repeat(${cols.length}, 1fr)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "agenda__corner"
  }), cols.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    className: "agenda__colhead"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.name,
    size: 34
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "agenda__prof"
  }, p.name), /*#__PURE__*/React.createElement("div", {
    className: "agenda__esp"
  }, p.esp, " \xB7 ", p.cons)))), /*#__PURE__*/React.createElement("div", {
    className: "agenda__grid",
    style: {
      gridTemplateColumns: `64px repeat(${cols.length}, 1fr)`
    }
  }, SLOTS.map((t, r) => /*#__PURE__*/React.createElement("div", {
    key: 'tl' + r,
    className: "agenda__time",
    style: {
      gridRow: r + 1,
      gridColumn: 1
    }
  }, t)), SLOTS.map((t, r) => cols.map((p, c) => /*#__PURE__*/React.createElement("div", {
    key: 'cell' + r + c,
    className: "agenda__cell",
    style: {
      gridRow: r + 1,
      gridColumn: c + 2
    }
  }))), cols.map((p, c) => TURNOS[p.id].map(turn => {
    const status = cancelledIds.includes(turn.id) ? 'cancelled' : turn.status;
    const isSel = selected && selected.id === turn.id;
    return /*#__PURE__*/React.createElement("button", {
      key: turn.id,
      className: 'appt appt--' + status + (isSel ? ' is-selected' : ''),
      style: {
        gridColumn: c + 2,
        gridRow: `${turn.start + 1} / span ${turn.span}`
      },
      onClick: () => onSelect({
        ...turn,
        status,
        prof: p
      })
    }, /*#__PURE__*/React.createElement("span", {
      className: "appt__time"
    }, SLOTS[turn.start]), /*#__PURE__*/React.createElement("span", {
      className: "appt__patient"
    }, turn.patient), /*#__PURE__*/React.createElement("span", {
      className: "appt__motivo"
    }, turn.motivo));
  }))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(ClinicaApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clinica-web/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/medico-web/medico-app.jsx
try { (() => {
/* ============================================================
   Pulso · Panel del médico — app (sidebar propio, login, routing)
   ============================================================ */
const {
  useState: useStateApp,
  useRef: useRefApp
} = React;
const MED_NAV = [{
  group: 'Hoy',
  items: [{
    id: 'agenda',
    label: 'Mi agenda',
    icon: 'calendar-check'
  }, {
    id: 'consulta',
    label: 'Atención',
    icon: 'stethoscope'
  }]
}, {
  group: 'Clínico',
  items: [{
    id: 'pacientes',
    label: 'Mis pacientes',
    icon: 'users-round'
  }, {
    id: 'disponibilidad',
    label: 'Mi disponibilidad',
    icon: 'calendar-days'
  }]
}];
const MED_META = {
  agenda: ['Mi agenda', 'Turnos del día'],
  consulta: ['Atención de turno', 'Consulta en curso'],
  pacientes: ['Mis pacientes', 'Pacientes en seguimiento'],
  disponibilidad: ['Mi disponibilidad', 'Horarios de consultorio']
};
function MedSidebar({
  view,
  go,
  onLogout
}) {
  const counts = {
    agenda: window.DATA && 7
  };
  return /*#__PURE__*/React.createElement("aside", {
    className: "side"
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.svg",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "side__brandname"
  }, "Pulso")), /*#__PURE__*/React.createElement("div", {
    className: "side__ws"
  }, /*#__PURE__*/React.createElement("span", {
    className: "side__ws-ic",
    style: {
      background: MI_ESP.color + '22',
      color: MI_ESP.color
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: MI_ESP.icon,
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__ws-name"
  }, MI_ESP.nombre), /*#__PURE__*/React.createElement("div", {
    className: "side__ws-meta"
  }, "Consultorio 4"))), /*#__PURE__*/React.createElement("nav", {
    className: "side__nav"
  }, MED_NAV.map(sec => /*#__PURE__*/React.createElement("div", {
    key: sec.group
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__group"
  }, sec.group), sec.items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    className: 'navitem' + (view === it.id ? ' is-active' : ''),
    onClick: () => go(it.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 19
  }), /*#__PURE__*/React.createElement("span", null, it.label), it.id === 'agenda' && /*#__PURE__*/React.createElement("span", {
    className: "navitem__count"
  }, "7")))))), /*#__PURE__*/React.createElement("div", {
    className: "side__foot"
  }, /*#__PURE__*/React.createElement("button", {
    className: "navitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 19
  }), /*#__PURE__*/React.createElement("span", null, "Configuraci\xF3n")), /*#__PURE__*/React.createElement("div", {
    className: "side__user"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: YO.nombre,
    size: 36,
    tone: MI_ESP.color
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__user-name"
  }, "Dra. ", YO.nombre), /*#__PURE__*/React.createElement("div", {
    className: "side__user-role"
  }, MI_ESP.nombre)), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--sm",
    title: "Cerrar sesi\xF3n",
    onClick: onLogout
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 17
  })))));
}

/* ---------- Login del médico ---------- */
function MedLogin({
  onEnter
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "login"
  }, /*#__PURE__*/React.createElement("div", {
    className: "login__brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "login__brand-top"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark-light.svg",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "login__brand-name"
  }, "Pulso")), /*#__PURE__*/React.createElement("div", {
    className: "login__brand-mid"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "login__headline"
  }, "Tu consultorio, sin fricci\xF3n."), /*#__PURE__*/React.createElement("p", {
    className: "login__sub"
  }, "Acceso profesional al ", window.DATA.HOSPITAL.nombre, ". Tu agenda del d\xEDa, historias cl\xEDnicas y atenci\xF3n de turnos en un solo lugar."), /*#__PURE__*/React.createElement("div", {
    className: "login__chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-check",
    size: 15
  }), "Agenda del d\xEDa"), /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "folder-open",
    size: 15
  }), "Historia cl\xEDnica"), /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "pill",
    size: 15
  }), "Recetas digitales"))), /*#__PURE__*/React.createElement("div", {
    className: "login__foot"
  }, "\xA9 2026 Pulso \xB7 ", window.DATA.HOSPITAL.red)), /*#__PURE__*/React.createElement("div", {
    className: "login__form"
  }, /*#__PURE__*/React.createElement("form", {
    className: "loginform",
    onSubmit: e => {
      e.preventDefault();
      onEnter();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "loginform__eyebrow"
  }, "Acceso profesional"), /*#__PURE__*/React.createElement("h1", {
    className: "loginform__title"
  }, "Inici\xE1 sesi\xF3n"), /*#__PURE__*/React.createElement("p", {
    className: "loginform__lead"
  }, "Ingres\xE1 con tu cuenta profesional del hospital."), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Correo electr\xF3nico"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "mail",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "pulso-input",
    type: "email",
    defaultValue: "l.romero@sanlucas.health"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Contrase\xF1a"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "pulso-input",
    type: "password",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  })), /*#__PURE__*/React.createElement("div", {
    className: "loginform__aux"
  }, /*#__PURE__*/React.createElement("span", {
    className: "loginlink"
  }, "\xBFOlvidaste tu contrase\xF1a?"))), /*#__PURE__*/React.createElement("div", {
    className: "loginform__cta"
  }, /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "pulso-btn pulso-btn--primary pulso-btn--lg pulso-btn--block"
  }, "Iniciar sesi\xF3n", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  }))))));
}

/* ---------- App ---------- */
function MedicoApp() {
  const [logged, setLogged] = useStateApp(false);
  const [view, setView] = useStateApp('agenda');
  const [pacId, setPacId] = useStateApp(38); // paciente en atención por defecto
  const [toast, setToast] = useStateApp('');
  const timer = useRefApp(null);
  const notify = msg => {
    setToast(msg);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(''), 2400);
  };
  const go = v => setView(v);
  const atender = id => {
    setPacId(id);
    setView('consulta');
  };
  if (!logged) return /*#__PURE__*/React.createElement(MedLogin, {
    onEnter: () => {
      setLogged(true);
      setView('agenda');
    }
  });
  const [title, sub] = MED_META[view] || ['', ''];
  const content = {
    agenda: /*#__PURE__*/React.createElement(MedAgenda, {
      go: go,
      atender: atender,
      notify: notify
    }),
    consulta: /*#__PURE__*/React.createElement(MedConsulta, {
      pacId: pacId,
      go: go,
      notify: notify
    }),
    pacientes: /*#__PURE__*/React.createElement(MedPacientes, {
      atender: atender
    }),
    disponibilidad: /*#__PURE__*/React.createElement(MedDisponibilidad, {
      notify: notify
    })
  }[view];
  return /*#__PURE__*/React.createElement("div", {
    className: "adm"
  }, /*#__PURE__*/React.createElement(MedSidebar, {
    view: view,
    go: go,
    onLogout: () => setLogged(false)
  }), /*#__PURE__*/React.createElement("div", {
    className: "main"
  }, /*#__PURE__*/React.createElement(Topbar, {
    title: title,
    sub: sub
  }), content), /*#__PURE__*/React.createElement(Toast, {
    msg: toast
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(MedicoApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/medico-web/medico-app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/medico-web/medico-views.jsx
try { (() => {
/* ============================================================
   Pulso · Panel del médico — vistas
   Médico en sesión: Dra. Lucía Romero (Cardiología, id 11)
   Reutiliza átomos de shell.jsx (Icon, Avatar, StatusPill,
   Badge, Topbar, Panel, Toast) y datos de data.jsx.
   ============================================================ */
const {
  useState
} = React;
const M = window.DATA;
const YO = M.medById(11); // Dra. Lucía Romero
const MI_ESP = M.espById(YO.esp); // Cardiología

// Agenda del día de la médica (estado: done | now | next | confirmed | pending)
const AGENDA_HOY = [{
  hora: '08:00',
  pac: 31,
  estado: 'done',
  motivo: 'Control anual'
}, {
  hora: '08:30',
  pac: 33,
  estado: 'done',
  motivo: 'Seguimiento HTA'
}, {
  hora: '09:00',
  pac: 38,
  estado: 'now',
  motivo: 'Palpitaciones'
}, {
  hora: '09:30',
  pac: 34,
  estado: 'next',
  motivo: 'Pre-quirúrgico'
}, {
  hora: '10:00',
  pac: 39,
  estado: 'confirmed',
  motivo: 'Control de presión'
}, {
  hora: '10:30',
  pac: 32,
  estado: 'pending',
  motivo: 'Primera consulta'
}, {
  hora: '11:00',
  pac: 36,
  estado: 'confirmed',
  motivo: 'Resultados de estudios'
}];

// Datos clínicos extra por paciente (no están en el padrón base)
const PT_EXTRA = {
  31: {
    edad: 34,
    sangre: '0+',
    alergias: ['Penicilina']
  },
  33: {
    edad: 61,
    sangre: 'A+',
    alergias: []
  },
  38: {
    edad: 28,
    sangre: 'B-',
    alergias: ['AINES', 'Polen']
  },
  34: {
    edad: 47,
    sangre: 'A-',
    alergias: []
  },
  39: {
    edad: 39,
    sangre: '0-',
    alergias: ['Iodo']
  },
  32: {
    edad: 52,
    sangre: 'AB+',
    alergias: []
  },
  36: {
    edad: 44,
    sangre: 'B+',
    alergias: []
  }
};
const extra = id => PT_EXTRA[id] || {
  edad: '—',
  sangre: '—',
  alergias: []
};
const SLOT_LABEL = {
  done: 'Atendido',
  now: 'En atención',
  next: 'Siguiente',
  confirmed: 'Confirmado',
  pending: 'Pendiente'
};

/* ---------------- Mi agenda (panel principal) ---------------- */
function MedAgenda({
  go,
  atender,
  notify
}) {
  const done = AGENDA_HOY.filter(s => s.estado === 'done').length;
  const total = AGENDA_HOY.length;
  const now = AGENDA_HOY.find(s => s.estado === 'now');
  const kpis = [{
    v: total,
    k: 'Turnos hoy',
    icon: 'calendar-days',
    tone: 'ic-primary'
  }, {
    v: done,
    k: 'Atendidos',
    icon: 'circle-check-big',
    tone: 'ic-info'
  }, {
    v: total - done,
    k: 'En espera',
    icon: 'clock',
    tone: 'ic-warning'
  }, {
    v: '4.8★',
    k: 'Satisfacción',
    icon: 'star',
    tone: 'ic-accent'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page__intro"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, "15 jun \xB7 Lunes"), /*#__PURE__*/React.createElement("div", {
    className: "page__hello"
  }, "Buenos d\xEDas, Dra. Romero"), /*#__PURE__*/React.createElement("div", {
    className: "page__date"
  }, "Ten\xE9s ", total - done, " pacientes en espera \xB7 ", MI_ESP.nombre)), now && (() => {
    const p = M.pacById(now.pac),
      e = extra(now.pac);
    return /*#__PURE__*/React.createElement("div", {
      className: "nowcard"
    }, /*#__PURE__*/React.createElement("span", {
      className: "nowcard__pulse"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        zIndex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "nowcard__label"
    }, /*#__PURE__*/React.createElement("span", {
      className: "nowcard__pulse",
      style: {
        position: 'static'
      }
    }), "En atenci\xF3n ahora \xB7 ", now.hora, " hs"), /*#__PURE__*/React.createElement("div", {
      className: "nowcard__name"
    }, p.nombre), /*#__PURE__*/React.createElement("div", {
      className: "nowcard__meta"
    }, e.edad, " a\xF1os \xB7 ", now.motivo, " \xB7 ", p.cobertura)), /*#__PURE__*/React.createElement("div", {
      className: "nowcard__right"
    }, /*#__PURE__*/React.createElement("button", {
      className: "pulso-btn pulso-btn--lg",
      style: {
        background: '#fff',
        color: 'var(--primary)'
      },
      onClick: () => atender(now.pac)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "stethoscope",
      size: 18
    }), "Continuar atenci\xF3n")));
  })(), /*#__PURE__*/React.createElement("div", {
    className: "kpis"
  }, kpis.map(it => /*#__PURE__*/React.createElement("div", {
    className: "kpi",
    key: it.k
  }, /*#__PURE__*/React.createElement("div", {
    className: "kpi__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'kpi__ic ' + it.tone
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "kpi__v"
  }, it.v), /*#__PURE__*/React.createElement("div", {
    className: "kpi__k"
  }, it.k)))), /*#__PURE__*/React.createElement(Panel, {
    title: "Agenda de hoy",
    sub: `${MI_ESP.nombre} · Consultorio 4`,
    flush: true,
    actions: /*#__PURE__*/React.createElement(Badge, {
      variant: "success",
      icon: "circle-check"
    }, done, " de ", total, " atendidos")
  }, /*#__PURE__*/React.createElement("div", {
    className: "agenda"
  }, AGENDA_HOY.map((s, i) => {
    const p = M.pacById(s.pac),
      e = extra(s.pac);
    const tone = {
      done: 'attended',
      now: 'confirmed',
      next: 'pending',
      confirmed: 'confirmed',
      pending: 'pending'
    }[s.estado];
    return /*#__PURE__*/React.createElement("div", {
      className: 'slot' + (s.estado === 'now' ? ' slot--now' : s.estado === 'done' ? ' slot--done' : ''),
      key: i
    }, /*#__PURE__*/React.createElement("div", {
      className: "slot__time"
    }, s.hora, /*#__PURE__*/React.createElement("small", null, SLOT_LABEL[s.estado])), /*#__PURE__*/React.createElement("div", {
      className: "slot__who"
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: p.nombre,
      size: 40,
      tone: s.estado === 'now' ? 'var(--primary)' : undefined
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "slot__name"
    }, p.nombre), /*#__PURE__*/React.createElement("div", {
      className: "slot__meta"
    }, s.motivo, " \xB7 ", e.edad, " a\xF1os \xB7 ", p.cobertura))), /*#__PURE__*/React.createElement("div", {
      className: "slot__right"
    }, s.estado === 'done' ? /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => atender(s.pac)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "file-text",
      size: 14
    }), "Ver consulta") : s.estado === 'pending' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      className: "pulso-status pulso-status--pending"
    }, /*#__PURE__*/React.createElement("span", {
      className: "pulso-status__dot"
    }), "Sin confirmar")) : /*#__PURE__*/React.createElement("button", {
      className: 'pulso-btn pulso-btn--sm ' + (s.estado === 'now' ? 'pulso-btn--primary' : 'pulso-btn--secondary'),
      onClick: () => atender(s.pac)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "stethoscope",
      size: 15
    }), "Atender")));
  }))));
}

/* ---------------- Atención de turno (consulta) ---------------- */
function MedConsulta({
  pacId,
  notify,
  go
}) {
  const p = M.pacById(pacId);
  const e = extra(pacId);
  const slot = AGENDA_HOY.find(s => s.pac === pacId) || {};
  const hist = M.HISTORIAL[pacId] || [];
  const [rx, setRx] = useState([{
    med: '',
    dosis: ''
  }]);
  const addRx = () => setRx(r => [...r, {
    med: '',
    dosis: ''
  }]);
  const delRx = i => setRx(r => r.length > 1 ? r.filter((_, j) => j !== i) : r);
  const vitals = [{
    k: 'Tensión arterial',
    u: 'mmHg',
    ph: '120/80',
    icon: 'gauge'
  }, {
    k: 'Frec. cardíaca',
    u: 'lpm',
    ph: '72',
    icon: 'heart-pulse'
  }, {
    k: 'Temperatura',
    u: '°C',
    ph: '36.5',
    icon: 'thermometer'
  }, {
    k: 'Sat. O₂',
    u: '%',
    ph: '98',
    icon: 'wind'
  }, {
    k: 'Peso',
    u: 'kg',
    ph: '68',
    icon: 'weight'
  }, {
    k: 'Talla',
    u: 'cm',
    ph: '170',
    icon: 'ruler'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("button", {
    className: "rowbtn",
    style: {
      marginBottom: 16
    },
    onClick: () => go('agenda')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 14
  }), "Volver a la agenda"), /*#__PURE__*/React.createElement("div", {
    className: "consult"
  }, /*#__PURE__*/React.createElement("section", {
    className: "panel",
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pt"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.nombre,
    size: 56,
    tone: MI_ESP.color
  }), /*#__PURE__*/React.createElement("div", {
    className: "pt__info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pt__name"
  }, p.nombre), /*#__PURE__*/React.createElement("div", {
    className: "pt__facts"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pt__fact"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user"
  }), " ", /*#__PURE__*/React.createElement("b", null, e.edad, " a\xF1os")), /*#__PURE__*/React.createElement("span", {
    className: "pt__fact"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "id-card"
  }), " DNI ", /*#__PURE__*/React.createElement("b", null, p.dni)), /*#__PURE__*/React.createElement("span", {
    className: "pt__fact"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "droplet"
  }), " Grupo ", /*#__PURE__*/React.createElement("b", null, e.sangre)), /*#__PURE__*/React.createElement("span", {
    className: "pt__fact"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield"
  }), " ", /*#__PURE__*/React.createElement("b", null, p.cobertura)))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement(StatusPill, {
    status: "confirmed"
  }), /*#__PURE__*/React.createElement("div", {
    className: "pt__fact",
    style: {
      justifyContent: 'flex-end',
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "clock"
  }), " ", slot.hora || '09:00', " hs \xB7 ", slot.motivo || 'Consulta'))), e.alergias.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "alerts"
  }, /*#__PURE__*/React.createElement("span", {
    className: "alerts__lead"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "triangle-alert"
  }), "Alergias"), e.alergias.map(a => /*#__PURE__*/React.createElement("span", {
    className: "alerttag",
    key: a
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-alert",
    size: 12
  }), a))), /*#__PURE__*/React.createElement("div", {
    className: "cblock"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cblock__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cblock__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "message-square-text",
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    className: "cblock__title"
  }, "Motivo de consulta")), /*#__PURE__*/React.createElement("textarea", {
    className: "ta",
    style: {
      minHeight: 64
    },
    defaultValue: slot.motivo ? slot.motivo + '. ' : '',
    placeholder: "Describ\xED el motivo y los s\xEDntomas referidos por el paciente\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    className: "cblock"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cblock__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cblock__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "activity",
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    className: "cblock__title"
  }, "Signos vitales"), /*#__PURE__*/React.createElement("span", {
    className: "cblock__hint"
  }, "Tomados en consultorio")), /*#__PURE__*/React.createElement("div", {
    className: "vitals"
  }, vitals.map(v => /*#__PURE__*/React.createElement("label", {
    className: "vital",
    key: v.k
  }, /*#__PURE__*/React.createElement("span", {
    className: "vital__k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: v.icon
  }), v.k), /*#__PURE__*/React.createElement("span", {
    className: "vital__in"
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: v.ph
  }), /*#__PURE__*/React.createElement("span", {
    className: "vital__u"
  }, v.u)))))), /*#__PURE__*/React.createElement("div", {
    className: "cblock"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cblock__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cblock__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "clipboard-plus",
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    className: "cblock__title"
  }, "Diagn\xF3stico")), /*#__PURE__*/React.createElement("textarea", {
    className: "ta",
    style: {
      minHeight: 64
    },
    placeholder: "Diagn\xF3stico presuntivo o confirmado, CIE-10 si corresponde\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    className: "cblock"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cblock__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cblock__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "pill",
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    className: "cblock__title"
  }, "Indicaciones y receta")), /*#__PURE__*/React.createElement("div", {
    className: "rx"
  }, rx.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "rxrow",
    key: i
  }, /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Medicamento (ej: Enalapril 10mg)"
  }), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    placeholder: "Posolog\xEDa (ej: 1 cada 12h)"
  }), /*#__PURE__*/React.createElement("button", {
    className: "rxrow__del",
    onClick: () => delRx(i),
    title: "Quitar"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trash-2",
    size: 16
  })))), /*#__PURE__*/React.createElement("button", {
    className: "rxadd",
    onClick: addRx
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus"
  }), "Agregar medicamento")), /*#__PURE__*/React.createElement("textarea", {
    className: "ta",
    style: {
      minHeight: 64,
      marginTop: 12
    },
    placeholder: "Indicaciones generales: reposo, hidrataci\xF3n, estudios solicitados, pr\xF3ximo control\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    className: "cfoot"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cfoot__note"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock"
  }), "La consulta se registra en la historia cl\xEDnica"), /*#__PURE__*/React.createElement("span", {
    className: "cfoot__sp"
  }), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary",
    onClick: () => notify('Borrador guardado')
  }, "Guardar borrador"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => {
      notify('Atención finalizada y registrada');
      go('agenda');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 17
  }), "Finalizar atenci\xF3n"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Panel, {
    title: "Resumen del paciente"
  }, /*#__PURE__*/React.createElement("div", {
    className: "snap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "snapcard"
  }, /*#__PURE__*/React.createElement("div", {
    className: "snapcard__k"
  }, "\xDAltima visita"), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__v"
  }, hist.length ? hist[0].fecha.split(' ').slice(0, 2).join(' ') : '—'), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__s"
  }, hist.length ? M.espById(hist[0].esp).nombre : 'Sin registros')), /*#__PURE__*/React.createElement("div", {
    className: "snapcard"
  }, /*#__PURE__*/React.createElement("div", {
    className: "snapcard__k"
  }, "Consultas"), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__v"
  }, hist.length), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__s"
  }, "en su historia")), /*#__PURE__*/React.createElement("div", {
    className: "snapcard"
  }, /*#__PURE__*/React.createElement("div", {
    className: "snapcard__k"
  }, "Ausencias"), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__v",
    style: {
      color: p.ausencias >= 2 ? 'var(--warning-ink)' : undefined
    }
  }, p.ausencias), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__s"
  }, "acumuladas")), /*#__PURE__*/React.createElement("div", {
    className: "snapcard"
  }, /*#__PURE__*/React.createElement("div", {
    className: "snapcard__k"
  }, "Cobertura"), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__v",
    style: {
      fontSize: 15
    }
  }, p.cobertura), /*#__PURE__*/React.createElement("div", {
    className: "snapcard__s"
  }, "Vigente")))), /*#__PURE__*/React.createElement(Panel, {
    title: "Antecedentes",
    sub: "Consultas previas"
  }, hist.length ? /*#__PURE__*/React.createElement("div", {
    className: "tl"
  }, hist.map((h, i) => {
    const m = M.medById(h.med),
      es = M.espById(h.esp);
    return /*#__PURE__*/React.createElement("div", {
      className: "tl__item",
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      className: "tl__dot",
      style: {
        background: es.color
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "tl__date"
    }, h.fecha), /*#__PURE__*/React.createElement("div", {
      className: "tl__card"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tl__title",
      style: {
        fontSize: 13.5
      }
    }, h.titulo), /*#__PURE__*/React.createElement("div", {
      className: "tl__meta"
    }, "Dr. ", m.nombre), /*#__PURE__*/React.createElement("div", {
      className: "tl__note",
      style: {
        fontSize: 12.5,
        marginTop: 6
      }
    }, h.nota)));
  })) : /*#__PURE__*/React.createElement("div", {
    className: "empty",
    style: {
      padding: '28px 16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "empty__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "folder-open",
    size: 26
  })), /*#__PURE__*/React.createElement("div", {
    className: "empty__t",
    style: {
      fontSize: 15
    }
  }, "Primera consulta"), /*#__PURE__*/React.createElement("p", {
    className: "empty__p",
    style: {
      fontSize: 13
    }
  }, "No hay registros previos de este paciente."))))));
}

/* ---------------- Mis pacientes ---------------- */
function MedPacientes({
  atender
}) {
  const ids = [...new Set(AGENDA_HOY.map(s => s.pac))];
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Mis pacientes",
    sub: `${ids.length} pacientes en seguimiento · ${MI_ESP.nombre}`,
    flush: true
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Paciente"), /*#__PURE__*/React.createElement("th", null, "Edad"), /*#__PURE__*/React.createElement("th", null, "Cobertura"), /*#__PURE__*/React.createElement("th", null, "\xDAltima consulta"), /*#__PURE__*/React.createElement("th", {
    className: "r"
  }, "Acci\xF3n"))), /*#__PURE__*/React.createElement("tbody", null, ids.map(id => {
    const p = M.pacById(id),
      e = extra(id);
    const h = (M.HISTORIAL[id] || [])[0];
    return /*#__PURE__*/React.createElement("tr", {
      key: id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "cellflex"
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: p.nombre,
      size: 38,
      tone: MI_ESP.color
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__name"
    }, p.nombre), /*#__PURE__*/React.createElement("div", {
      className: "tbl__muted",
      style: {
        fontSize: 12.5
      }
    }, "DNI ", p.dni)))), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, e.edad, " a\xF1os"), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
      variant: "neutral",
      icon: "shield"
    }, p.cobertura)), /*#__PURE__*/React.createElement("td", {
      className: "tbl__muted"
    }, h ? h.fecha : 'Sin registros'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "tbl__actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => atender(id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "folder-open",
      size: 14
    }), "Historia"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => atender(id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "stethoscope",
      size: 14
    }), "Atender"))));
  })))));
}

/* ---------------- Mi disponibilidad ---------------- */
const DIAS = [{
  d: 1,
  n: 'Lunes'
}, {
  d: 2,
  n: 'Martes'
}, {
  d: 3,
  n: 'Miércoles'
}, {
  d: 4,
  n: 'Jueves'
}, {
  d: 5,
  n: 'Viernes'
}, {
  d: 6,
  n: 'Sábado'
}];
function MedDisponibilidad({
  notify
}) {
  const mis = M.AGENDAS.filter(a => a.med === YO.id);
  // aseguro algo de contenido para la médica de ejemplo
  const bloques = mis.length ? mis : [{
    id: 1,
    dia: 1,
    ini: '08:00',
    fin: '12:00'
  }, {
    id: 2,
    dia: 4,
    ini: '08:00',
    fin: '11:00'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Cargar bloque de atenci\xF3n",
    sub: "Defin\xED tus horarios de consultorio (se repiten cada semana)"
  }, /*#__PURE__*/React.createElement("div", {
    className: "formgrid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 170
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "D\xEDa"), /*#__PURE__*/React.createElement("select", {
    className: "fld"
  }, DIAS.map(d => /*#__PURE__*/React.createElement("option", {
    key: d.d
  }, d.n)))), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 130
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Desde"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "time",
    defaultValue: "08:00"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 130
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Hasta"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    type: "time",
    defaultValue: "12:00"
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      width: 150
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Consultorio"), /*#__PURE__*/React.createElement("input", {
    className: "fld",
    defaultValue: "Consultorio 4"
  })), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => notify('Bloque agregado a tu disponibilidad')
  }, "Agregar bloque"))), /*#__PURE__*/React.createElement(Panel, {
    title: "Mi semana",
    sub: `${MI_ESP.nombre} · horarios habilitados`
  }, /*#__PURE__*/React.createElement("div", {
    className: "avail"
  }, DIAS.map(d => {
    const dayBlocks = bloques.filter(b => b.dia === d.d);
    return /*#__PURE__*/React.createElement("div", {
      className: "availday",
      key: d.d
    }, /*#__PURE__*/React.createElement("div", {
      className: "availday__h"
    }, d.n.slice(0, 3)), /*#__PURE__*/React.createElement("div", {
      className: "availday__b"
    }, dayBlocks.length ? dayBlocks.map((b, i) => /*#__PURE__*/React.createElement("div", {
      className: "availblock",
      key: i
    }, b.ini, "\u2013", b.fin, /*#__PURE__*/React.createElement("small", null, "Consultorio 4"))) : /*#__PURE__*/React.createElement("div", {
      className: "availday__empty"
    }, "\u2014")));
  }))));
}
Object.assign(window, {
  MedAgenda,
  MedConsulta,
  MedPacientes,
  MedDisponibilidad,
  YO,
  MI_ESP
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/medico-web/medico-views.jsx", error: String((e && e.message) || e) }); }

// ui_kits/paciente-movil/app.jsx
try { (() => {
const {
  useState,
  useRef,
  useEffect,
  useLayoutEffect
} = React;

/* ---------- Icono (Lucide) ---------- */
function Icon({
  name,
  size = 20,
  color,
  style
}) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const el = ref.current;
    el.innerHTML = `<i data-lucide="${name}"></i>`;
    window.lucide && window.lucide.createIcons();
    const svg = el.querySelector('svg');
    if (svg) {
      svg.style.width = size + 'px';
      svg.style.height = size + 'px';
      if (color) svg.style.color = color;
    }
  });
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      ...style
    }
  });
}

/* ---------- Datos ---------- */
const ESPECIALIDADES = [{
  id: 'clinica',
  label: 'Clínica médica',
  icon: 'stethoscope'
}, {
  id: 'cardio',
  label: 'Cardiología',
  icon: 'heart-pulse'
}, {
  id: 'derma',
  label: 'Dermatología',
  icon: 'scan-face'
}, {
  id: 'pedia',
  label: 'Pediatría',
  icon: 'baby'
}, {
  id: 'odonto',
  label: 'Odontología',
  icon: 'smile'
}, {
  id: 'oftalmo',
  label: 'Oftalmología',
  icon: 'eye'
}];
const PROFESIONALES = [{
  id: 'romero',
  name: 'Dra. Lucía Romero',
  esp: 'Cardiología',
  lugar: 'Clínica Norte · Cons. 4',
  rating: '4.9'
}, {
  id: 'paz',
  name: 'Dr. Andrés Paz',
  esp: 'Cardiología',
  lugar: 'Sede Centro · Cons. 12',
  rating: '4.8'
}];
const DAYS = [['Lun', 9], ['Mar', 10], ['Mié', 11], ['Jue', 12], ['Vie', 13]];
const SLOTS = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '15:00', '15:30', '16:00'];
const OCUPADOS = ['10:30', '15:30'];
const TURNOS = [{
  id: 1,
  doc: 'Dra. Lucía Romero',
  esp: 'Cardiología',
  fecha: 'Mar 10 jun',
  hora: '09:30',
  estado: 'confirmed',
  lugar: 'Clínica Norte · Cons. 4'
}, {
  id: 2,
  doc: 'Dr. Tomás Vidal',
  esp: 'Clínica médica',
  fecha: 'Lun 23 jun',
  hora: '11:00',
  estado: 'pending',
  lugar: 'Sede Centro · Cons. 7'
}];
const HISTORIAL = [{
  id: 3,
  doc: 'Dra. Paula Sosa',
  esp: 'Dermatología',
  fecha: '14 may',
  hora: '16:00',
  estado: 'attended',
  lugar: 'Clínica Norte'
}, {
  id: 4,
  doc: 'Dr. Andrés Paz',
  esp: 'Cardiología',
  fecha: '2 may',
  hora: '10:00',
  estado: 'cancelled',
  lugar: 'Sede Centro'
}];
const ESTADO_LABEL = {
  confirmed: 'Confirmado',
  pending: 'Pendiente',
  attended: 'Atendido',
  cancelled: 'Cancelado'
};

/* ---------- Átomos (clases del design system) ---------- */
const Avatar = ({
  name,
  size = 44,
  square
}) => {
  const ini = name.replace(/^(Dra?\.|Dr\.)\s*/, '').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", {
    className: "pulso-avatar",
    style: {
      width: size,
      height: size,
      borderRadius: square ? 'var(--radius-md)' : '50%',
      fontSize: size * 0.34
    }
  }, ini);
};
const Badge = ({
  tone = 'neutral',
  children
}) => /*#__PURE__*/React.createElement("span", {
  className: `pulso-badge pulso-badge--${tone}`
}, children);
const StatusPill = ({
  status
}) => /*#__PURE__*/React.createElement("span", {
  className: `pulso-status pulso-status--${status}`
}, /*#__PURE__*/React.createElement("span", {
  className: "pulso-status__dot"
}), ESTADO_LABEL[status]);

/* ---------- Shell del teléfono ---------- */
function Phone({
  children,
  onBack,
  title,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "phone"
  }, /*#__PURE__*/React.createElement("div", {
    className: "phone__notch"
  }), /*#__PURE__*/React.createElement("div", {
    className: "phone__statusbar"
  }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "signal",
    size: 15
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 15
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "battery-full",
    size: 15
  }))), children);
}

/* ---------- Barra de navegación inferior ---------- */
function TabBar({
  screen,
  go
}) {
  const items = [{
    id: 'inicio',
    icon: 'house',
    label: 'Inicio'
  }, {
    id: 'reservar',
    icon: 'calendar-plus',
    label: 'Reservar'
  }, {
    id: 'turnos',
    icon: 'calendar-days',
    label: 'Turnos'
  }, {
    id: 'perfil',
    icon: 'user-round',
    label: 'Perfil'
  }];
  return /*#__PURE__*/React.createElement("nav", {
    className: "tabbar"
  }, items.map(it => {
    const active = screen === it.id || it.id === 'reservar' && screen === 'confirmado';
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      className: 'tabbar__item' + (active ? ' is-active' : ''),
      onClick: () => go(it.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: it.icon,
      size: 22
    }), /*#__PURE__*/React.createElement("span", null, it.label));
  }));
}

/* ---------- Pantalla: Inicio ---------- */
function Inicio({
  go
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "screen-scroll"
  }, /*#__PURE__*/React.createElement("header", {
    className: "appbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.svg",
    alt: "",
    width: "30",
    height: "30"
  }), /*#__PURE__*/React.createElement("span", null, "Pulso")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 20
  })), /*#__PURE__*/React.createElement(Avatar, {
    name: "Mart\xEDn Acosta",
    size: 36
  }))), /*#__PURE__*/React.createElement("div", {
    className: "screen-body"
  }, /*#__PURE__*/React.createElement("p", {
    className: "greet-sub"
  }, "Buenas tardes,"), /*#__PURE__*/React.createElement("h1", {
    className: "greet"
  }, "Mart\xEDn Acosta"), /*#__PURE__*/React.createElement("div", {
    className: "next-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "next-card__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-eyebrow",
    style: {
      color: '#9FE3BE'
    }
  }, "Pr\xF3ximo turno"), /*#__PURE__*/React.createElement(StatusPillLight, {
    status: "confirmed"
  })), /*#__PURE__*/React.createElement("div", {
    className: "next-card__doc"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Luc\xEDa Romero",
    size: 46
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "next-card__name"
  }, "Dra. Luc\xEDa Romero"), /*#__PURE__*/React.createElement("div", {
    className: "next-card__esp"
  }, "Cardiolog\xEDa \xB7 Cl\xEDnica Norte"))), /*#__PURE__*/React.createElement("div", {
    className: "next-card__when"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 16
  }), " Mar 10 de junio"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    name: "clock",
    size: 16
  }), " 09:30 hs"))), /*#__PURE__*/React.createElement("div", {
    className: "quick"
  }, /*#__PURE__*/React.createElement("button", {
    className: "quick__btn",
    onClick: () => go('reservar')
  }, /*#__PURE__*/React.createElement("span", {
    className: "quick__ic",
    style: {
      background: 'var(--green-soft)',
      color: 'var(--primary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-plus",
    size: 22
  })), "Reservar turno"), /*#__PURE__*/React.createElement("button", {
    className: "quick__btn",
    onClick: () => go('turnos')
  }, /*#__PURE__*/React.createElement("span", {
    className: "quick__ic",
    style: {
      background: 'var(--info-soft)',
      color: 'var(--info)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 22
  })), "Mis turnos")), /*#__PURE__*/React.createElement("div", {
    className: "sec-head"
  }, /*#__PURE__*/React.createElement("h2", null, "Especialidades"), /*#__PURE__*/React.createElement("button", {
    className: "link",
    onClick: () => go('reservar')
  }, "Ver todas")), /*#__PURE__*/React.createElement("div", {
    className: "esp-grid"
  }, ESPECIALIDADES.slice(0, 6).map(e => /*#__PURE__*/React.createElement("button", {
    key: e.id,
    className: "esp-cell",
    onClick: () => go('reservar')
  }, /*#__PURE__*/React.createElement("span", {
    className: "esp-cell__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: e.icon,
    size: 22
  })), /*#__PURE__*/React.createElement("span", {
    className: "esp-cell__lb"
  }, e.label))))));
}
const StatusPillLight = ({
  status
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    fontSize: 12,
    fontWeight: 600,
    color: '#fff',
    background: 'rgba(255,255,255,.16)',
    padding: '4px 10px',
    borderRadius: 999
  }
}, /*#__PURE__*/React.createElement("span", {
  style: {
    width: 7,
    height: 7,
    borderRadius: 99,
    background: '#5FD69B'
  }
}), ESTADO_LABEL[status]);

/* ---------- Pantalla: Reservar ---------- */
function Reservar({
  go
}) {
  const [esp, setEsp] = useState('cardio');
  const [prof, setProf] = useState('romero');
  const [day, setDay] = useState(10);
  const [slot, setSlot] = useState('09:30');
  const profe = PROFESIONALES.find(p => p.id === prof);
  return /*#__PURE__*/React.createElement("div", {
    className: "screen-scroll"
  }, /*#__PURE__*/React.createElement("header", {
    className: "appbar appbar--plain"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn",
    onClick: () => go('inicio')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 22
  })), /*#__PURE__*/React.createElement("span", {
    className: "appbar__title"
  }, "Reservar turno"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "screen-body"
  }, /*#__PURE__*/React.createElement("p", {
    className: "field-label"
  }, "Especialidad"), /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, ESPECIALIDADES.map(e => /*#__PURE__*/React.createElement("button", {
    key: e.id,
    className: 'chip' + (esp === e.id ? ' is-on' : ''),
    onClick: () => setEsp(e.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: e.icon,
    size: 16
  }), e.label))), /*#__PURE__*/React.createElement("p", {
    className: "field-label"
  }, "Profesional"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, PROFESIONALES.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.id,
    className: 'prof' + (prof === p.id ? ' is-on' : ''),
    onClick: () => setProf(p.id)
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.name,
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    className: "prof__meta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "prof__name"
  }, p.name), /*#__PURE__*/React.createElement("div", {
    className: "prof__sub"
  }, p.lugar)), /*#__PURE__*/React.createElement("span", {
    className: "prof__rating"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "star",
    size: 13
  }), p.rating)))), /*#__PURE__*/React.createElement("p", {
    className: "field-label"
  }, "Fecha ", /*#__PURE__*/React.createElement("span", {
    className: "field-label__hint"
  }, "Junio 2026")), /*#__PURE__*/React.createElement("div", {
    className: "days"
  }, DAYS.map(([d, n]) => /*#__PURE__*/React.createElement("button", {
    key: n,
    className: "pulso-day",
    "aria-pressed": day === n,
    onClick: () => setDay(n)
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-day__dow"
  }, d), /*#__PURE__*/React.createElement("span", {
    className: "pulso-day__num"
  }, n)))), /*#__PURE__*/React.createElement("p", {
    className: "field-label"
  }, "Horario disponible"), /*#__PURE__*/React.createElement("div", {
    className: "slots"
  }, SLOTS.map(t => {
    const off = OCUPADOS.includes(t);
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      className: "pulso-slot",
      "aria-pressed": slot === t,
      disabled: off,
      onClick: () => setSlot(t)
    }, t);
  }))), /*#__PURE__*/React.createElement("div", {
    className: "screen-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "foot-summary"
  }, /*#__PURE__*/React.createElement("span", {
    className: "foot-summary__lb"
  }, "Turno seleccionado"), /*#__PURE__*/React.createElement("span", {
    className: "foot-summary__val"
  }, profe.name.split(' ').slice(0, 2).join(' '), " \xB7 ", day, " jun \xB7 ", slot)), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary",
    onClick: () => go('confirmado')
  }, "Confirmar", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  }))));
}

/* ---------- Pantalla: Confirmado ---------- */
function Confirmado({
  go
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "screen-scroll"
  }, /*#__PURE__*/React.createElement("div", {
    className: "confirm-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "confirm-check"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 32,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("h2", null, "Turno confirmado"), /*#__PURE__*/React.createElement("p", null, "Le enviamos los detalles por correo y un recordatorio 24\xA0hs antes.")), /*#__PURE__*/React.createElement("div", {
    className: "screen-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulso-card pulso-card--pad",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "detail-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail-ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user-round",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "detail-k"
  }, "Profesional"), /*#__PURE__*/React.createElement("div", {
    className: "detail-v"
  }, "Dra. Luc\xEDa Romero"))), /*#__PURE__*/React.createElement("div", {
    className: "detail-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail-ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "detail-k"
  }, "Fecha y hora"), /*#__PURE__*/React.createElement("div", {
    className: "detail-v"
  }, "Mar 10 de junio \xB7 09:30 hs"))), /*#__PURE__*/React.createElement("div", {
    className: "detail-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail-ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "detail-k"
  }, "Lugar"), /*#__PURE__*/React.createElement("div", {
    className: "detail-v"
  }, "Cl\xEDnica Norte \xB7 Consultorio 4")))), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary pulso-btn--block",
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-plus",
    size: 18
  }), "Agregar al calendario"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary pulso-btn--block",
    style: {
      marginTop: 10
    },
    onClick: () => go('turnos')
  }, "Ver mis turnos")));
}

/* ---------- Pantalla: Mis turnos ---------- */
function MisTurnos({
  go
}) {
  const [tab, setTab] = useState('proximos');
  const [cancelId, setCancelId] = useState(null);
  const lista = tab === 'proximos' ? TURNOS : HISTORIAL;
  return /*#__PURE__*/React.createElement("div", {
    className: "screen-scroll"
  }, /*#__PURE__*/React.createElement("header", {
    className: "appbar appbar--plain"
  }, /*#__PURE__*/React.createElement("span", {
    className: "appbar__title",
    style: {
      marginRight: 'auto',
      fontSize: 20
    }
  }, "Mis turnos"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--solid",
    onClick: () => go('reservar')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "screen-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulso-seg",
    style: {
      display: 'flex',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-seg__item",
    "aria-selected": tab === 'proximos',
    style: {
      flex: 1
    },
    onClick: () => setTab('proximos')
  }, "Pr\xF3ximos"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-seg__item",
    "aria-selected": tab === 'historial',
    style: {
      flex: 1
    },
    onClick: () => setTab('historial')
  }, "Historial")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, lista.map(t => /*#__PURE__*/React.createElement("div", {
    key: t.id,
    className: "pulso-card pulso-card--pad turno-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "turno-card__head"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: t.doc,
    size: 42
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "turno-card__doc"
  }, t.doc), /*#__PURE__*/React.createElement("div", {
    className: "turno-card__esp"
  }, t.esp)), /*#__PURE__*/React.createElement(StatusPill, {
    status: t.estado
  })), /*#__PURE__*/React.createElement("div", {
    className: "turno-card__info"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 15
  }), t.fecha), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    name: "clock",
    size: 15
  }), t.hora, " hs"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 15
  }), t.lugar)), tab === 'proximos' && (cancelId === t.id ? /*#__PURE__*/React.createElement("div", {
    className: "cancel-confirm"
  }, /*#__PURE__*/React.createElement("span", null, "\xBFCancelar este turno?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--ghost pulso-btn--sm",
    onClick: () => setCancelId(null)
  }, "No"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--danger pulso-btn--sm",
    onClick: () => setCancelId(null)
  }, "S\xED, cancelar"))) : /*#__PURE__*/React.createElement("div", {
    className: "turno-card__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary pulso-btn--sm",
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "pencil",
    size: 16
  }), "Reprogramar"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--ghost pulso-btn--sm",
    style: {
      color: 'var(--danger)'
    },
    onClick: () => setCancelId(t.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 16
  }), "Cancelar"))))))));
}

/* ---------- Pantalla: Perfil ---------- */
function Perfil() {
  const [rec, setRec] = useState(true);
  const [sms, setSms] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "screen-scroll"
  }, /*#__PURE__*/React.createElement("header", {
    className: "appbar appbar--plain"
  }, /*#__PURE__*/React.createElement("span", {
    className: "appbar__title",
    style: {
      fontSize: 20
    }
  }, "Perfil")), /*#__PURE__*/React.createElement("div", {
    className: "screen-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "profile-hero"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Mart\xEDn Acosta",
    size: 64
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "profile-hero__name"
  }, "Mart\xEDn Acosta"), /*#__PURE__*/React.createElement("div", {
    className: "profile-hero__sub"
  }, "martin.acosta@correo.com"))), /*#__PURE__*/React.createElement("div", {
    className: "pulso-card",
    style: {
      overflow: 'hidden',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "setting"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setting__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "Mis datos m\xE9dicos"), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "setting"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setting__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "Obra social y cobertura"), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "setting"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setting__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "credit-card",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "Medios de pago"), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pulso-card",
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "setting"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setting__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "mail",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "Recordatorios por correo"), /*#__PURE__*/React.createElement("label", {
    className: "pulso-switch"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: rec,
    onChange: e => setRec(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__thumb"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "setting"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setting__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "message-square",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "Recordatorios por SMS"), /*#__PURE__*/React.createElement("label", {
    className: "pulso-switch"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: sms,
    onChange: e => setSms(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__thumb"
  })))))));
}

/* ---------- App ---------- */
function PacienteApp() {
  const [screen, setScreen] = useState('inicio');
  const go = s => setScreen(s);
  const map = {
    inicio: Inicio,
    reservar: Reservar,
    confirmado: Confirmado,
    turnos: MisTurnos,
    perfil: Perfil
  };
  const Current = map[screen];
  return /*#__PURE__*/React.createElement("div", {
    className: "phone"
  }, /*#__PURE__*/React.createElement("div", {
    className: "phone__notch"
  }), /*#__PURE__*/React.createElement("div", {
    className: "phone__statusbar"
  }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "signal",
    size: 15
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 15
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "battery-full",
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    className: "phone__view"
  }, /*#__PURE__*/React.createElement(Current, {
    go: go
  })), /*#__PURE__*/React.createElement(TabBar, {
    screen: screen,
    go: go
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(PacienteApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/paciente-movil/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/paciente-web/paciente-app.jsx
try { (() => {
/* ============================================================
   Pulso · Portal web del paciente — app (sidebar, login, routing)
   ============================================================ */
const {
  useState: useStatePApp,
  useRef: useRefPApp
} = React;
const PAC_NAV = [{
  group: 'Mi salud',
  items: [{
    id: 'inicio',
    label: 'Inicio',
    icon: 'house'
  }, {
    id: 'reservar',
    label: 'Reservar turno',
    icon: 'calendar-plus'
  }, {
    id: 'turnos',
    label: 'Mis turnos',
    icon: 'calendar-days',
    count: 2
  }]
}, {
  group: 'Mi información',
  items: [{
    id: 'historia',
    label: 'Historia clínica',
    icon: 'folder-open'
  }, {
    id: 'perfil',
    label: 'Mi perfil',
    icon: 'user-round'
  }]
}];
const PAC_META = {
  inicio: ['Inicio', 'Tu portal de salud'],
  reservar: ['Reservar turno', 'Elegí especialidad, profesional y horario'],
  turnos: ['Mis turnos', 'Próximos e historial'],
  historia: ['Historia clínica', 'Tus consultas y estudios'],
  perfil: ['Mi perfil', 'Datos y preferencias']
};
function PacSidebar({
  view,
  go,
  onLogout
}) {
  return /*#__PURE__*/React.createElement("aside", {
    className: "side"
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.svg",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "side__brandname"
  }, "Pulso")), /*#__PURE__*/React.createElement("div", {
    className: "side__ws"
  }, /*#__PURE__*/React.createElement("span", {
    className: "side__ws-ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "hospital",
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__ws-name"
  }, window.DATA.HOSPITAL.nombre), /*#__PURE__*/React.createElement("div", {
    className: "side__ws-meta"
  }, "Portal del paciente"))), /*#__PURE__*/React.createElement("nav", {
    className: "side__nav"
  }, PAC_NAV.map(sec => /*#__PURE__*/React.createElement("div", {
    key: sec.group
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__group"
  }, sec.group), sec.items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    className: 'navitem' + (view === it.id ? ' is-active' : ''),
    onClick: () => go(it.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 19
  }), /*#__PURE__*/React.createElement("span", null, it.label), it.count && /*#__PURE__*/React.createElement("span", {
    className: "navitem__count"
  }, it.count)))))), /*#__PURE__*/React.createElement("div", {
    className: "side__foot"
  }, /*#__PURE__*/React.createElement("button", {
    className: "navitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-help",
    size: 19
  }), /*#__PURE__*/React.createElement("span", null, "Ayuda")), /*#__PURE__*/React.createElement("div", {
    className: "side__user"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: MI_PAC.nombre,
    size: 36,
    tone: "var(--primary)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "side__user-name"
  }, MI_PAC.nombre), /*#__PURE__*/React.createElement("div", {
    className: "side__user-role"
  }, "Paciente")), /*#__PURE__*/React.createElement("button", {
    className: "pulso-iconbtn pulso-iconbtn--sm",
    title: "Cerrar sesi\xF3n",
    onClick: onLogout
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 17
  })))));
}

/* ---------- Login del paciente ---------- */
function PacLogin({
  onEnter
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "login"
  }, /*#__PURE__*/React.createElement("div", {
    className: "login__brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "login__brand-top"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark-light.svg",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "login__brand-name"
  }, "Pulso")), /*#__PURE__*/React.createElement("div", {
    className: "login__brand-mid"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "login__headline"
  }, "Tu salud, a un clic."), /*#__PURE__*/React.createElement("p", {
    className: "login__sub"
  }, "Reserv\xE1 turnos, consult\xE1 tu historia cl\xEDnica y gestion\xE1 tus datos en el portal de ", window.DATA.HOSPITAL.nombre, "."), /*#__PURE__*/React.createElement("div", {
    className: "login__chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-plus",
    size: 15
  }), "Reserv\xE1 online"), /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 15
  }), "Recordatorios"), /*#__PURE__*/React.createElement("span", {
    className: "login__chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "folder-open",
    size: 15
  }), "Historia cl\xEDnica"))), /*#__PURE__*/React.createElement("div", {
    className: "login__foot"
  }, "\xA9 2026 Pulso \xB7 ", window.DATA.HOSPITAL.red)), /*#__PURE__*/React.createElement("div", {
    className: "login__form"
  }, /*#__PURE__*/React.createElement("form", {
    className: "loginform",
    onSubmit: e => {
      e.preventDefault();
      onEnter();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "loginform__eyebrow"
  }, "Portal del paciente"), /*#__PURE__*/React.createElement("h1", {
    className: "loginform__title"
  }, "Inici\xE1 sesi\xF3n"), /*#__PURE__*/React.createElement("p", {
    className: "loginform__lead"
  }, "Ingres\xE1 con tu cuenta para gestionar tus turnos."), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Correo electr\xF3nico"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "mail",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "pulso-input",
    type: "email",
    defaultValue: "m.acosta@correo.com"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field__label"
  }, "Contrase\xF1a"), /*#__PURE__*/React.createElement("div", {
    className: "pulso-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "pulso-input",
    type: "password",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  })), /*#__PURE__*/React.createElement("div", {
    className: "loginform__aux"
  }, /*#__PURE__*/React.createElement("span", {
    className: "loginlink"
  }, "\xBFOlvidaste tu contrase\xF1a?"))), /*#__PURE__*/React.createElement("div", {
    className: "loginform__cta"
  }, /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "pulso-btn pulso-btn--primary pulso-btn--lg pulso-btn--block"
  }, "Iniciar sesi\xF3n", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  }))), /*#__PURE__*/React.createElement("p", {
    className: "loginform__alt"
  }, "\xBFPrimera vez? ", /*#__PURE__*/React.createElement("span", {
    className: "loginlink"
  }, "Cre\xE1 tu cuenta")))));
}

/* ---------- App ---------- */
function PacienteApp() {
  const [logged, setLogged] = useStatePApp(false);
  const [view, setView] = useStatePApp('inicio');
  const [confirm, setConfirm] = useStatePApp(null);
  const [toast, setToast] = useStatePApp('');
  const timer = useRefPApp(null);
  const notify = msg => {
    setToast(msg);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(''), 2400);
  };
  const go = v => setView(v);
  const confirmar = data => setConfirm(data);
  if (!logged) return /*#__PURE__*/React.createElement(PacLogin, {
    onEnter: () => {
      setLogged(true);
      setView('inicio');
    }
  });
  const [title, sub] = PAC_META[view] || ['', ''];
  const content = {
    inicio: /*#__PURE__*/React.createElement(PacInicio, {
      go: go
    }),
    reservar: /*#__PURE__*/React.createElement(PacReservar, {
      notify: notify,
      confirmar: confirmar
    }),
    turnos: /*#__PURE__*/React.createElement(PacTurnos, {
      go: go,
      notify: notify
    }),
    historia: /*#__PURE__*/React.createElement(PacHistoria, null),
    perfil: /*#__PURE__*/React.createElement(PacPerfil, {
      notify: notify
    })
  }[view];
  return /*#__PURE__*/React.createElement("div", {
    className: "adm"
  }, /*#__PURE__*/React.createElement(PacSidebar, {
    view: view,
    go: go,
    onLogout: () => setLogged(false)
  }), /*#__PURE__*/React.createElement("div", {
    className: "main"
  }, /*#__PURE__*/React.createElement(Topbar, {
    title: title,
    sub: sub,
    noSearch: true
  }), content), confirm && /*#__PURE__*/React.createElement(PacConfirm, {
    data: confirm,
    onClose: () => setConfirm(null),
    go: go
  }), /*#__PURE__*/React.createElement(Toast, {
    msg: toast
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(PacienteApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/paciente-web/paciente-app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/paciente-web/paciente-views.jsx
try { (() => {
/* ============================================================
   Pulso · Portal web del paciente — vistas
   Paciente en sesión: Martín Acosta (id 32)
   Reutiliza átomos de shell.jsx y datos de data.jsx.
   ============================================================ */
const {
  useState: useStateP
} = React;
const P = window.DATA;
const MI = P.pacById(32); // Martín Acosta

// Próximo turno destacado y listas (derivadas de los datos del hospital)
const PROX = [{
  id: 1043,
  dia: '16',
  mes: 'jun',
  fechaTxt: 'Lunes 16 de junio',
  hora: '08:30',
  med: 12,
  esp: 2,
  estado: 'confirmed',
  lugar: 'Sede Centro · Consultorio 7'
}, {
  id: 1062,
  dia: '23',
  mes: 'jun',
  fechaTxt: 'Lunes 23 de junio',
  hora: '11:00',
  med: 11,
  esp: 1,
  estado: 'pending',
  lugar: 'Sede Centro · Consultorio 4'
}];
const PASADOS = [{
  id: 1042,
  dia: '14',
  mes: 'may',
  fechaTxt: 'Miércoles 14 de mayo',
  hora: '16:00',
  med: 13,
  esp: 3,
  estado: 'attended',
  lugar: 'Sede Centro · Consultorio 9'
}, {
  id: 1031,
  dia: '02',
  mes: 'may',
  fechaTxt: 'Viernes 2 de mayo',
  hora: '10:00',
  med: 11,
  esp: 1,
  estado: 'cancelled',
  lugar: 'Sede Centro · Consultorio 4'
}];
const PROXIMO = PROX[0];

/* ---------------- Inicio ---------------- */
function PacInicio({
  go
}) {
  const med = P.medById(PROXIMO.med),
    esp = P.espById(PROXIMO.esp);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page__intro"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, "Hola de nuevo"), /*#__PURE__*/React.createElement("div", {
    className: "page__hello"
  }, MI.nombre), /*#__PURE__*/React.createElement("div", {
    className: "page__date"
  }, "Bienvenido a tu portal de ", P.HOSPITAL.nombre, ".")), /*#__PURE__*/React.createElement("div", {
    className: "phero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "phero__eyebrow"
  }, "Tu pr\xF3ximo turno"), /*#__PURE__*/React.createElement("div", {
    className: "phero__doc"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: med.nombre,
    size: 50,
    tone: "rgba(255,255,255,.18)",
    color: "#fff"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "phero__name"
  }, "Dr. ", med.nombre), /*#__PURE__*/React.createElement("div", {
    className: "phero__esp"
  }, esp.nombre, " \xB7 ", PROXIMO.lugar.split(' · ')[0])), /*#__PURE__*/React.createElement("span", {
    className: "pchip",
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "pchip__dot"
  }), "Confirmado")), /*#__PURE__*/React.createElement("div", {
    className: "phero__when"
  }, /*#__PURE__*/React.createElement("div", {
    className: "phero__fact"
  }, /*#__PURE__*/React.createElement("span", {
    className: "phero__fact-k"
  }, "Fecha"), /*#__PURE__*/React.createElement("span", {
    className: "phero__fact-v"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 16
  }), PROXIMO.dia, " jun")), /*#__PURE__*/React.createElement("div", {
    className: "phero__fact"
  }, /*#__PURE__*/React.createElement("span", {
    className: "phero__fact-k"
  }, "Hora"), /*#__PURE__*/React.createElement("span", {
    className: "phero__fact-v"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "clock",
    size: 16
  }), PROXIMO.hora, " hs")), /*#__PURE__*/React.createElement("div", {
    className: "phero__fact"
  }, /*#__PURE__*/React.createElement("span", {
    className: "phero__fact-k"
  }, "Lugar"), /*#__PURE__*/React.createElement("span", {
    className: "phero__fact-v"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 16
  }), "Cons. ", PROXIMO.lugar.split('Consultorio ')[1]))), /*#__PURE__*/React.createElement("div", {
    className: "phero__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--sm",
    style: {
      background: '#fff',
      color: 'var(--primary)'
    },
    onClick: () => go('turnos')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 15
  }), "Ver mis turnos"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--sm",
    style: {
      background: 'rgba(255,255,255,.14)',
      color: '#fff',
      borderColor: 'transparent'
    },
    onClick: () => go('reservar')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "repeat",
    size: 15
  }), "Reprogramar"))), /*#__PURE__*/React.createElement("div", {
    className: "quick"
  }, /*#__PURE__*/React.createElement("button", {
    className: "quickbtn",
    onClick: () => go('reservar')
  }, /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__ic",
    style: {
      background: 'var(--green-soft)',
      color: 'var(--primary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-plus",
    size: 22
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__t"
  }, "Reservar turno"), /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__s"
  }, "Eleg\xED especialidad y horario"))), /*#__PURE__*/React.createElement("button", {
    className: "quickbtn",
    onClick: () => go('turnos')
  }, /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__ic",
    style: {
      background: 'var(--info-soft)',
      color: 'var(--info)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 22
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__t"
  }, "Mis turnos"), /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__s"
  }, PROX.length, " pr\xF3ximos"))), /*#__PURE__*/React.createElement("button", {
    className: "quickbtn",
    onClick: () => go('historia')
  }, /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__ic",
    style: {
      background: 'var(--warning-soft)',
      color: 'var(--warning)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "folder-open",
    size: 22
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__t"
  }, "Mi historia cl\xEDnica"), /*#__PURE__*/React.createElement("span", {
    className: "quickbtn__s"
  }, "Consultas y estudios")))), /*#__PURE__*/React.createElement(Panel, {
    title: "Especialidades",
    sub: "Reserv\xE1 con un profesional",
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => go('reservar')
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 14
    }), "Ver todas")
  }, /*#__PURE__*/React.createElement("div", {
    className: "espweb"
  }, P.ESPECIALIDADES.map(e => {
    const n = P.MEDICOS.filter(m => m.esp === e.id).length;
    return /*#__PURE__*/React.createElement("button", {
      className: "espweb__cell",
      key: e.id,
      onClick: () => go('reservar')
    }, /*#__PURE__*/React.createElement("span", {
      className: "espweb__ic",
      style: {
        background: e.color
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: e.icon,
      size: 22
    })), /*#__PURE__*/React.createElement("span", {
      className: "espweb__lb"
    }, e.nombre), /*#__PURE__*/React.createElement("span", {
      className: "espweb__meta"
    }, n, " ", n === 1 ? 'profesional' : 'profesionales'));
  }))));
}

/* ---------------- Reservar turno ---------------- */
const DIAS_RES = [['Lun', '15'], ['Mar', '16'], ['Mié', '17'], ['Jue', '18'], ['Vie', '19']];
const SLOTS_RES = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '15:00', '15:30', '16:00', '16:30'];
const OCUPADOS_RES = ['10:30', '15:30'];
function PacReservar({
  notify,
  confirmar
}) {
  const [espId, setEspId] = useStateP(1);
  const profesionales = P.MEDICOS.filter(m => m.esp === espId);
  const [medId, setMedId] = useStateP(profesionales[0] ? profesionales[0].id : null);
  const [dia, setDia] = useStateP('16');
  const [slot, setSlot] = useStateP('09:30');
  const pickEsp = id => {
    setEspId(id);
    const first = P.MEDICOS.find(m => m.esp === id);
    setMedId(first ? first.id : null);
  };
  const esp = P.espById(espId);
  const med = medId ? P.medById(medId) : null;
  const ratings = {
    11: '4.9',
    12: '4.8',
    13: '4.7',
    14: '4.9',
    15: '4.6',
    16: '4.8',
    17: '4.7'
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "resv"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement("p", {
    className: "steplabel"
  }, /*#__PURE__*/React.createElement("span", {
    className: "steplabel__n"
  }, "1"), "Especialidad"), /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, P.ESPECIALIDADES.map(e => /*#__PURE__*/React.createElement("button", {
    key: e.id,
    className: 'chip' + (espId === e.id ? ' is-on' : ''),
    onClick: () => pickEsp(e.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: e.icon,
    size: 15
  }), e.nombre)))), /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement("p", {
    className: "steplabel"
  }, /*#__PURE__*/React.createElement("span", {
    className: "steplabel__n"
  }, "2"), "Profesional", /*#__PURE__*/React.createElement("small", null, profesionales.length, " disponibles en ", esp.nombre)), /*#__PURE__*/React.createElement("div", {
    className: "proflist"
  }, profesionales.map(m => /*#__PURE__*/React.createElement("button", {
    key: m.id,
    className: 'profpick' + (medId === m.id ? ' is-on' : ''),
    onClick: () => setMedId(m.id)
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: m.nombre,
    size: 44,
    tone: esp.color
  }), /*#__PURE__*/React.createElement("div", {
    className: "profpick__meta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "profpick__name"
  }, "Dr. ", m.nombre), /*#__PURE__*/React.createElement("div", {
    className: "profpick__sub"
  }, esp.nombre, " \xB7 ", m.matricula)), /*#__PURE__*/React.createElement("span", {
    className: "profpick__rating"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "star",
    size: 14
  }), ratings[m.id] || '4.8'), /*#__PURE__*/React.createElement("span", {
    className: "profpick__check"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 13
  })))))), /*#__PURE__*/React.createElement(Panel, null, /*#__PURE__*/React.createElement("p", {
    className: "steplabel"
  }, /*#__PURE__*/React.createElement("span", {
    className: "steplabel__n"
  }, "3"), "Fecha", /*#__PURE__*/React.createElement("small", null, "Junio 2026")), /*#__PURE__*/React.createElement("div", {
    className: "daysrow"
  }, DIAS_RES.map(([d, n]) => /*#__PURE__*/React.createElement("button", {
    key: n,
    className: "pulso-day",
    "aria-pressed": dia === n,
    onClick: () => setDia(n)
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-day__dow"
  }, d), /*#__PURE__*/React.createElement("span", {
    className: "pulso-day__num"
  }, n)))), /*#__PURE__*/React.createElement("p", {
    className: "steplabel",
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "steplabel__n"
  }, "4"), "Horario", /*#__PURE__*/React.createElement("small", null, "Turnos de 30 min")), /*#__PURE__*/React.createElement("div", {
    className: "slotsgrid"
  }, SLOTS_RES.map(t => {
    const off = OCUPADOS_RES.includes(t);
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      className: "pulso-slot",
      "aria-pressed": slot === t,
      disabled: off,
      onClick: () => setSlot(t)
    }, t);
  })))), /*#__PURE__*/React.createElement("div", {
    className: "summary"
  }, /*#__PURE__*/React.createElement("div", {
    className: "summary__head"
  }, "Resumen del turno"), /*#__PURE__*/React.createElement("div", {
    className: "summary__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "summary__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "summary__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: esp.icon,
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "summary__k"
  }, "Especialidad"), /*#__PURE__*/React.createElement("div", {
    className: "summary__v"
  }, esp.nombre))), /*#__PURE__*/React.createElement("div", {
    className: "summary__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "summary__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user-round",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "summary__k"
  }, "Profesional"), /*#__PURE__*/React.createElement("div", {
    className: "summary__v"
  }, med ? 'Dr. ' + med.nombre : '—'))), /*#__PURE__*/React.createElement("div", {
    className: "summary__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "summary__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "summary__k"
  }, "Fecha y hora"), /*#__PURE__*/React.createElement("div", {
    className: "summary__v"
  }, dia, " jun \xB7 ", slot, " hs"))), /*#__PURE__*/React.createElement("div", {
    className: "summary__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "summary__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 17
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "summary__k"
  }, "Lugar"), /*#__PURE__*/React.createElement("div", {
    className: "summary__v"
  }, "Sede Centro")))), /*#__PURE__*/React.createElement("div", {
    className: "summary__foot"
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary pulso-btn--block",
    onClick: () => confirmar({
      esp,
      med,
      dia,
      slot
    })
  }, "Confirmar turno", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 17
  }))))));
}

/* ---------------- Confirmación (overlay) ---------------- */
function PacConfirm({
  data,
  onClose,
  go
}) {
  const {
    esp,
    med,
    dia,
    slot
  } = data;
  return /*#__PURE__*/React.createElement("div", {
    className: "cov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "covcard",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "covhero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "covcheck"
  }, /*#__PURE__*/React.createElement("span", {
    className: "covcheck__ring"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 32,
    color: "#fff"
  }))), /*#__PURE__*/React.createElement("h2", null, "\xA1Turno confirmado!"), /*#__PURE__*/React.createElement("p", null, "Te enviamos los detalles por correo y un recordatorio 24 hs antes.")), /*#__PURE__*/React.createElement("div", {
    className: "covbody"
  }, /*#__PURE__*/React.createElement("div", {
    className: "covdetail"
  }, /*#__PURE__*/React.createElement("span", {
    className: "covdetail__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user-round",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "covdetail__k"
  }, "Profesional"), /*#__PURE__*/React.createElement("div", {
    className: "covdetail__v"
  }, med ? 'Dr. ' + med.nombre : '—'))), /*#__PURE__*/React.createElement("div", {
    className: "covdetail"
  }, /*#__PURE__*/React.createElement("span", {
    className: "covdetail__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: esp.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "covdetail__k"
  }, "Especialidad"), /*#__PURE__*/React.createElement("div", {
    className: "covdetail__v"
  }, esp.nombre))), /*#__PURE__*/React.createElement("div", {
    className: "covdetail"
  }, /*#__PURE__*/React.createElement("span", {
    className: "covdetail__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-days",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "covdetail__k"
  }, "Fecha y hora"), /*#__PURE__*/React.createElement("div", {
    className: "covdetail__v"
  }, dia, " de junio \xB7 ", slot, " hs"))), /*#__PURE__*/React.createElement("div", {
    className: "covdetail"
  }, /*#__PURE__*/React.createElement("span", {
    className: "covdetail__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "covdetail__k"
  }, "Lugar"), /*#__PURE__*/React.createElement("div", {
    className: "covdetail__v"
  }, "Sede Centro \xB7 Consultorio 4"))), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary pulso-btn--block",
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar-plus",
    size: 17
  }), "Agregar al calendario"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--primary pulso-btn--block",
    style: {
      marginTop: 10
    },
    onClick: () => {
      onClose();
      go('turnos');
    }
  }, "Ver mis turnos"))));
}

/* ---------------- Mis turnos ---------------- */
function PacTurnos({
  go,
  notify
}) {
  const [tab, setTab] = useStateP('proximos');
  const [cancelId, setCancelId] = useStateP(null);
  const lista = tab === 'proximos' ? PROX : PASADOS;
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Mis turnos",
    sub: "Tus reservas en el hospital",
    actions: /*#__PURE__*/React.createElement("button", {
      className: "pulso-btn pulso-btn--primary pulso-btn--sm",
      onClick: () => go('reservar')
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 16
    }), "Reservar turno")
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulso-seg",
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "pulso-seg__item",
    "aria-selected": tab === 'proximos',
    onClick: () => {
      setTab('proximos');
      setCancelId(null);
    }
  }, "Pr\xF3ximos"), /*#__PURE__*/React.createElement("button", {
    className: "pulso-seg__item",
    "aria-selected": tab === 'historial',
    onClick: () => {
      setTab('historial');
      setCancelId(null);
    }
  }, "Historial")), /*#__PURE__*/React.createElement("div", {
    className: "turnolist"
  }, lista.map(t => {
    const med = P.medById(t.med),
      esp = P.espById(t.esp);
    return /*#__PURE__*/React.createElement("div", {
      className: "tcard",
      key: t.id
    }, /*#__PURE__*/React.createElement("div", {
      className: "tcard__date"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tcard__day"
    }, t.dia), /*#__PURE__*/React.createElement("div", {
      className: "tcard__mon"
    }, t.mes)), /*#__PURE__*/React.createElement("div", {
      className: "tcard__main"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tcard__doc"
    }, "Dr. ", med.nombre), /*#__PURE__*/React.createElement("div", {
      className: "tcard__facts"
    }, /*#__PURE__*/React.createElement("span", {
      className: "tcard__fact"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espdot",
      style: {
        background: esp.color
      }
    }), esp.nombre), /*#__PURE__*/React.createElement("span", {
      className: "tcard__fact"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "clock",
      size: 14
    }), t.hora, " hs"), /*#__PURE__*/React.createElement("span", {
      className: "tcard__fact"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "map-pin",
      size: 14
    }), t.lugar))), /*#__PURE__*/React.createElement("div", {
      className: "tcard__right"
    }, /*#__PURE__*/React.createElement(StatusPill, {
      status: t.estado
    }), tab === 'proximos' && (cancelId === t.id ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12.5,
        color: 'var(--text-muted)'
      }
    }, "\xBFCancelar?"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => setCancelId(null)
    }, "No"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn rowbtn--danger",
      onClick: () => {
        setCancelId(null);
        notify('Turno cancelado');
      }
    }, "S\xED")) : /*#__PURE__*/React.createElement("div", {
      className: "tcard__btns"
    }, /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => notify('Reprogramar turno')
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "pencil",
      size: 14
    }), "Reprogramar"), /*#__PURE__*/React.createElement("button", {
      className: "rowbtn rowbtn--danger",
      onClick: () => setCancelId(t.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "x",
      size: 14
    }), "Cancelar"))), tab === 'historial' && t.estado === 'attended' && /*#__PURE__*/React.createElement("button", {
      className: "rowbtn",
      onClick: () => go('historia')
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "file-text",
      size: 14
    }), "Ver detalle")));
  }))));
}

/* ---------------- Mi historia clínica ---------------- */
function PacHistoria() {
  // Historia de ejemplo del paciente (reusa estructura de HISTORIAL)
  const items = [{
    fecha: '14 may 2026',
    titulo: 'Consulta dermatológica',
    med: 13,
    esp: 3,
    nota: 'Control de lunares. Sin lesiones sospechosas. Se recomienda fotoprotección diaria y control anual.'
  }, {
    fecha: '02 abr 2026',
    titulo: 'Control clínico',
    med: 12,
    esp: 2,
    nota: 'Chequeo general. Laboratorio dentro de parámetros normales. Continúa sin medicación.'
  }, {
    fecha: '18 nov 2025',
    titulo: 'Electrocardiograma',
    med: 11,
    esp: 1,
    nota: 'ECG normal, ritmo sinusal. Se solicita control en 12 meses.'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Mi historia cl\xEDnica",
    sub: `${MI.nombre} · DNI ${MI.dni} · ${MI.cobertura}`,
    actions: /*#__PURE__*/React.createElement("button", {
      className: "rowbtn"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 14
    }), "Descargar")
  }, /*#__PURE__*/React.createElement("div", {
    className: "tl"
  }, items.map((h, i) => {
    const m = P.medById(h.med),
      e = P.espById(h.esp);
    return /*#__PURE__*/React.createElement("div", {
      className: "tl__item",
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      className: "tl__dot",
      style: {
        background: e.color
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "tl__date"
    }, h.fecha), /*#__PURE__*/React.createElement("div", {
      className: "tl__card"
    }, /*#__PURE__*/React.createElement("div", {
      className: "tl__title"
    }, h.titulo), /*#__PURE__*/React.createElement("div", {
      className: "tl__meta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "espchip",
      style: {
        fontSize: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "espdot",
      style: {
        background: e.color
      }
    }), e.nombre), " \xB7 Dr. ", m.nombre), /*#__PURE__*/React.createElement("div", {
      className: "tl__note"
    }, h.nota)));
  }))));
}

/* ---------------- Mi perfil ---------------- */
function PacPerfil({
  notify
}) {
  const [rec, setRec] = useStateP(true);
  const [sms, setSms] = useStateP(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "profhero"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: MI.nombre,
    size: 64,
    tone: "var(--primary)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "profhero__name"
  }, MI.nombre), /*#__PURE__*/React.createElement("div", {
    className: "profhero__sub"
  }, MI.email)), /*#__PURE__*/React.createElement("button", {
    className: "pulso-btn pulso-btn--secondary pulso-btn--sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "pencil",
    size: 15
  }), "Editar")), /*#__PURE__*/React.createElement("div", {
    className: "cols cols--1-1"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Mi cuenta",
    flush: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "setlist"
  }, /*#__PURE__*/React.createElement("div", {
    className: "setrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setrow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "id-card",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "setrow__t"
  }, "Datos personales"), /*#__PURE__*/React.createElement("div", {
    className: "setrow__s"
  }, "DNI ", MI.dni, " \xB7 ", MI.tel)), /*#__PURE__*/React.createElement("span", {
    className: "setrow__chev"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "setrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setrow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "setrow__t"
  }, "Obra social y cobertura"), /*#__PURE__*/React.createElement("div", {
    className: "setrow__s"
  }, MI.cobertura)), /*#__PURE__*/React.createElement("span", {
    className: "setrow__chev"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "setrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setrow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "credit-card",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "setrow__t"
  }, "Medios de pago"), /*#__PURE__*/React.createElement("div", {
    className: "setrow__s"
  }, "Visa \u2022\u2022\u2022\u2022 4821")), /*#__PURE__*/React.createElement("span", {
    className: "setrow__chev"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  }))))), /*#__PURE__*/React.createElement(Panel, {
    title: "Preferencias",
    flush: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "setlist"
  }, /*#__PURE__*/React.createElement("div", {
    className: "setrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setrow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "mail",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "setrow__t"
  }, "Recordatorios por correo"), /*#__PURE__*/React.createElement("div", {
    className: "setrow__s"
  }, "24 hs antes del turno")), /*#__PURE__*/React.createElement("label", {
    className: "pulso-switch setrow__sp"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: rec,
    onChange: e => {
      setRec(e.target.checked);
      notify(e.target.checked ? 'Recordatorios por correo activados' : 'Recordatorios desactivados');
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__thumb"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "setrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setrow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "message-square",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "setrow__t"
  }, "Recordatorios por SMS"), /*#__PURE__*/React.createElement("div", {
    className: "setrow__s"
  }, "Al n\xFAmero ", MI.tel)), /*#__PURE__*/React.createElement("label", {
    className: "pulso-switch setrow__sp"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: sms,
    onChange: e => setSms(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pulso-switch__thumb"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "setrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "setrow__ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "setrow__t"
  }, "Seguridad"), /*#__PURE__*/React.createElement("div", {
    className: "setrow__s"
  }, "Cambiar contrase\xF1a")), /*#__PURE__*/React.createElement("span", {
    className: "setrow__chev"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  })))))));
}
Object.assign(window, {
  PacInicio,
  PacReservar,
  PacConfirm,
  PacTurnos,
  PacHistoria,
  PacPerfil,
  MI_PAC: MI
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/paciente-web/paciente-views.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.SegmentedTabs = __ds_scope.SegmentedTabs;

__ds_ns.DayPill = __ds_scope.DayPill;

__ds_ns.TimeSlot = __ds_scope.TimeSlot;

})();
