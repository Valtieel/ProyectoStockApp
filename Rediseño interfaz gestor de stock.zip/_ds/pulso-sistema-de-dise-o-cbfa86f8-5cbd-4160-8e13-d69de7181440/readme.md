# Pulso — Sistema de diseño

**Pulso** es un sistema de diseño para una **app de gestión de turnos médicos**. Cubre los tres roles del producto —**paciente**, **profesional** y **recepción/administración**— en sus dos superficies: una **app móvil** (para pacientes) y un **panel web** (para la clínica). El sistema es minimalista, sobrio y de tono profesional, con una identidad verde tranquila pero con carácter.

> El nombre **"Pulso"** y la marca son **provisionales**. Se pueden cambiar sin tocar la estructura del sistema (logo en `assets/`, color y tipo en `tokens/`).

---

## Origen y fuentes

Este sistema se construyó **desde cero**, sin una base de marca previa. El producto de referencia es un gestor de turnos médicos todavía en etapa temprana de desarrollo.

- **Repositorio mencionado:** `Criss3402/TP` (rama `feature`, subárbol `cancelar-turno-doctor-agendas-persistentes/`) — no se importó código porque el usuario indicó que el proyecto está "muy crudo" y prefería partir de cero. La función de **cancelar turno por parte del profesional** sí se tomó como caso de uso central y está implementada en el kit web. Si más adelante se conecta el repo, conviene revisarlo para alinear nombres de entidades, estados de turno y flujos reales.

Dirección visual elegida por el usuario: fusión **"Sereno + Carácter"** (ver `explorations/`).

---

## Dirección de marca: "Sereno con carácter"

La base tranquila de **Sereno** —lienzo off-white, esquinas redondeadas, sombras suaves, mucho aire— combinada con la identidad de **Carácter**: verde bosque profundo, un verde brillante de acento y titulares firmes. Profesional y calmo, pero con personalidad. Pensado para que **todo tipo de personas** (de cualquier edad) lo usen sin fricción.

---

## CONTENT FUNDAMENTALS — cómo se escribe en Pulso

**Tono:** profesional y formal, pero cálido. Se trata de salud: la copy transmite cuidado y claridad, nunca frialdad ni jerga técnica innecesaria.

- **Trato de usted.** "Reserve su consulta", "Le enviamos los detalles", "Indique el motivo". Nunca "reservá" ni "tu turno" en la interfaz formal. (En materiales internos del equipo el trato puede relajarse.)
- **Claro y directo.** Frases cortas, verbo al frente en los botones: *Confirmar turno*, *Reservar*, *Cancelar turno*, *Ver mis turnos*. Nada de "¡Listo!" ni signos de exclamación.
- **Primera persona plural para la app.** La app habla como institución: "Le enviamos un recordatorio", "Le confirmamos su turno". Da respaldo y confianza.
- **Casing tipo oración (sentence case).** Títulos y botones en sentence case: "Reservar turno", no "Reservar Turno". Solo los *eyebrows*/kickers van en MAYÚSCULAS con tracking amplio ("NUEVO TURNO", "PRÓXIMO TURNO").
- **Estados de turno, siempre con la misma palabra:** *Confirmado*, *Pendiente*, *Cancelado*, *Atendido*, *Disponible*. No variar sinónimos.
- **Sin emoji.** La marca no usa emoji en la interfaz. La expresividad viene del color y la tipografía, no de iconos decorativos.
- **Datos médicos con respeto y precisión.** "Dra. Lucía Romero · Cardiología", "Cobertura: OSDE", "Clínica Norte · Consultorio 4". Abreviaturas consistentes: *Cons.* para consultorio, *hs* para horas.
- **Mensajes de cancelación, transparentes.** Cuando se cancela un turno se explica la consecuencia: "Se notificará al paciente por correo. Indique el motivo de la cancelación."

**Ejemplos reales del sistema:**
- Título: *"Reserve su consulta"*
- Confirmación: *"Turno confirmado — Le enviamos los detalles por correo y un recordatorio 24 hs antes."*
- Acción destructiva: *"Cancelar turno"* / *"Confirmar cancelación"*
- Vacío/ayuda: *"Sin puntos ni espacios"* (hint de DNI)

---

## VISUAL FOUNDATIONS

**Paleta.** Verde como color de marca, sobre neutros fríos con un leve tinte verde.
- **Primario — Bosque `#1C5E44`**: botones primarios, días/horarios seleccionados, navegación activa. Hover más oscuro (`#184E39`), pressed (`#143F2F`).
- **Acento — Brillante `#2FA86B`**: eyebrows, el círculo de check de confirmación, detalles puntuales. Se usa con moderación, como chispa.
- **Verde suave `#E4F1E8`**: fondos de avatares, chips activos tenues, iconos de especialidad. El "respiro" verde.
- **Tinta `#143025`**: texto fuerte (casi negro verdoso). Cuerpo en `#2C3B33`.
- **Lienzo `#F3F6F1`**: fondo de la app. Las superficies (tarjetas) van en blanco puro.
- **Semánticos:** éxito = verde brillante, aviso = ámbar `#C9852A`, peligro/cancelar = rojo terracota `#C0473B`, info/atendido = azul `#2D6E9E`. Cada uno con su variante *soft* para fondos.

**Tipografía.** Dos familias gratuitas de Google Fonts.
- **Space Grotesk** (display): titulares, números, horarios, montos. Geométrica, firme, con carácter. Pesos 600–700 para títulos.
- **Hanken Grotesk** (cuerpo): texto, etiquetas, hints. Humanista, clara, amable. Pesos 400–600.
- Escala de display: 38 / 30 / 24 / 18. Cuerpo 15–16. Etiquetas 13. Caption/eyebrow 12 (eyebrow en mayúsculas, tracking `0.14em`).
- Tracking negativo (`-0.02em`) en titulares grandes para densidad y firmeza.

**Espaciado.** Escala base **4px** (8, 12, 16, 24, 32, 48, 64…). Ritmo generoso: las pantallas respiran.

**Radios.** Suaves y redondeados. **19px es el radio firma** de las tarjetas (`--radius-card`). Controles 12px, inputs 12px, chips/pills 999px. Botones 12px.

**Sombras / elevación.** Sombras **muy suaves, difusas, con tinte verde** (no grises neutros). Bajísima opacidad y blur amplio (`0 12px 30px -18px rgba(20,48,37,.22)`). Los CTAs primarios llevan una sombra teñida de verde (`--shadow-primary`) que los hace "flotar" levemente. Nada de sombras duras ni bordes marcados.

**Fondos.** Predominio de lienzo off-white plano. En la app móvil, gradientes radiales verdes muy sutiles en las esquinas dan atmósfera sin ruido. Las tarjetas destacadas (próximo turno, confirmación) usan un **gradiente verde diagonal** (bosque → más oscuro) con un círculo translúcido decorativo. No se usan texturas, grano ni patrones.

**Bordes.** Hairline de 1px en `--border` (`#E7ECE6`); 1.5px en controles interactivos (inputs, chips, slots) para que el estado de foco/selección se lea bien.

**Estados.**
- *Hover*: oscurecer el fondo (primarios) o teñir de verde suave + borde primario (secundarios, chips, slots). Tarjetas interactivas: se elevan 2px y suben la sombra.
- *Press/active*: `translateY(1px)` en botones (hundido sutil), color pressed más oscuro.
- *Foco*: anillo de 3px verde translúcido (`--focus-ring`), nunca outline del navegador.
- *Seleccionado*: relleno verde sólido (días, profesional) o verde suave + borde (horarios).
- *Deshabilitado*: opacidad ~0.45; horarios ocupados tachados.

**Animación.** Discreta y rápida (140–180ms, ease). Transiciones de color/borde/sombra. Una excepción con personalidad: el **pulgar del switch** usa un easing con leve rebote (`cubic-bezier(.34,1.4,.6,1)`). Sin animaciones decorativas en bucle.

**Transparencia y blur.** Uso puntual: capas blancas translúcidas sobre los gradientes verdes (badges sobre la tarjeta de próximo turno). No hay glassmorphism general.

**Imagery.** El producto es funcional, no editorial: prioriza datos y avatares (iniciales sobre verde suave) por encima de fotos. Si se incorporan fotos de profesionales, mantener un tratamiento cálido y natural.

**Layout.** App móvil: 390px, tab bar inferior fija de 4 destinos, app bar superior. Web: sidebar fija de 264px + topbar + contenido scrolleable, con panel de detalle de 360px que entra desde la derecha.

---

## ICONOGRAPHY

- **Sistema:** [**Lucide**](https://lucide.dev) — iconos SVG de **trazo ~2px, redondeado** (línea, no relleno). Encajan con la calma y la limpieza de la marca.
- **Carga:** vía CDN (`https://unpkg.com/lucide@latest`). En React se renderizan con un pequeño componente `Icon` que inyecta `<i data-lucide="…">` y llama a `lucide.createIcons()`. *Sustitución declarada:* no había un set propio en el producto, así que se adoptó Lucide como estándar — si el equipo prefiere otro (Phosphor, Heroicons), se cambia solo la fuente del icono.
- **Tamaños:** 16px (inline en chips/listas), 18–20px (botones, filas), 22–24px (accesos, especialidades).
- **Iconos clave del dominio:** `stethoscope`, `heart-pulse`, `calendar-days`, `calendar-plus`, `clock`, `user-round`, `map-pin`, `bell`, `pill`, `shield` (cobertura), `clipboard-list` (motivo). Ver la card *Iconografía* en la pestaña Design System.
- **Sin emoji ni caracteres unicode** como iconos. Todo es Lucide.
- **Logo:** marca propia en `assets/` — cuadrado redondeado verde con un **estetoscopio** de trazo blanco y un punto de acento brillante en la campana (no usa corazón/línea de ECG). Variantes: `logo-mark.svg` (sobre claro), `logo-mark-light.svg` (sobre verde/oscuro), `logo-wordmark.svg` (con tipografía). Hechos como geometría simple; reemplazables.

---

## Índice del sistema

**Raíz**
- `styles.css` — punto de entrada único (solo `@import`s). Esto es lo que linkean los consumidores.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `elevation.css`, `base.css`.
- `css/components.css` — capa de clases `pulso-*` que usan los componentes React.
- `assets/` — logos (mark, mark-light, wordmark).
- `SKILL.md` — guía para usar este sistema como Agent Skill.

**Componentes** (`components/`) — primitivos React. API por nombre vía `window.PulsoSistemaDeDiseO_cbfa86`.
- `buttons/` — **Button**, **IconButton**
- `forms/` — **Input**, **Switch**, **Checkbox**
- `data-display/` — **Card**, **Avatar**, **Badge**, **StatusPill**
- `scheduling/` — **TimeSlot**, **DayPill** (primitivos de reserva de turnos)
- `navigation/` — **SegmentedTabs**

**UI kits** (`ui_kits/`) — recreaciones de pantallas reales, interactivas.
- `paciente-movil/` — app móvil del paciente: inicio, reservar turno, confirmación, mis turnos (con cancelación), perfil.
- `clinica-web/` — panel web de la clínica: agenda de recepción y médico, métricas, y **cancelación de turno por el profesional** con motivo.
- `clinica-admin/` — **panel web del administrador** (rol con acceso total): login partido, dashboard con **3 variantes** (resumen / operativo / analítico), supervisión de turnos, horarios (calendario mensual), especialidades, médicos, pacientes, usuarios, pagos, suspensiones, historiales clínicos y estadísticas. Sidebar claro con activo verde, iconos Lucide y voseo. Datos de ejemplo: Hospital San Lucas.
- `medico-web/` — **panel web del médico** (Dra. Lucía Romero, Cardiología): login profesional, mi agenda del día con banner de "en atención", **atención de turno** (header de paciente con alergias, signos vitales, motivo, diagnóstico, receta editable y antecedentes al costado), mis pacientes y mi disponibilidad semanal. Reutiliza los datos y átomos de `clinica-admin/`.
- `paciente-web/` — **portal web del paciente** (Martín Acosta): login, inicio con hero de próximo turno + accesos rápidos + especialidades, **reservar turno** (especialidad → profesional → fecha → horario con resumen pegajoso y confirmación en overlay), mis turnos (próximos / historial con cancelación inline), historia clínica y perfil con preferencias. Versión web del flujo de `paciente-movil/`. Reutiliza datos y átomos de `clinica-admin/`.

**Guidelines / specimen cards** (`guidelines/`) — tarjetas de la pestaña Design System: colores (marca, neutros, semánticos), tipografía (display, cuerpo, escala), espaciado (escala, radios, elevación), marca (logo, iconografía).

**Explorations** (`explorations/`) — las 4 direcciones iniciales y la fusión elegida. Material de referencia, no parte del sistema.

---

## Cómo lo usan los consumidores

1. Linkear `styles.css` (trae tokens, fuentes y la capa de componentes).
2. Cargar React UMD + el bundle compilado `_ds_bundle.js` y leer componentes desde `window.PulsoSistemaDeDiseO_cbfa86`.
3. Componer con los primitivos; para pantallas completas, partir de los UI kits.
4. Respetar las CONTENT FUNDAMENTALS (trato de usted, sin emoji, estados con vocabulario fijo).
